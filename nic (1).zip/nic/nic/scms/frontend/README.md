# SCMS Frontend

React-based Supply Chain Management System with separate **Admin Portal** and **Employee/User Portal**.

## Getting Started

### Prerequisites
- Node.js (v16 or higher)
- npm

### Installation

```bash
cd nic/scms/frontend
npm install
npm start
```

The app will open at `http://localhost:3000`.

### Build for Production

```bash
npm run build
```

## Login Credentials

**Admin Portal**
- Username: `TRP_RDD_2301`
- Password: `Scms@2301`

**Employee Portal**
- Username: any active Employee ID (e.g. `EMP-0001`, seeded by default; new ones can be added by Admin under Employees)
- Password: `user123`

## Architecture

A single shared data store is kept in `localStorage` under the key `scms_store` (see `src/store.js`). Both portals read/write this same store and poll it every 2 seconds, so changes made in the Admin Portal (new notifications, new materials, employee updates, etc.) are reflected in the Employee Portal automatically, and vice versa for chat messages and purchase requests.

> Note: this is a front-end-only demo data layer (localStorage). For a real production deployment, replace `src/store.js` with calls to the Express backend / a real database, and add proper authentication.

## Key Features

### Portal Selection
- A landing screen lets the user choose between the **Admin Portal** and the **Employee Portal**. No auto sign-in — every visit requires logging in with username, password, and CAPTCHA.

### Admin Portal
- **Dashboard** — live counts for employees, materials, inventory, stores, suppliers, manufacture orders, notifications, pending requests.
- **Notifications** — compose and send a notification to all employees; see replies; mark all as read; delete.
- **Inventory** — add/edit/delete inventory items, low-stock highlighting.
- **Stores** — manage store records (ID, name, location, manager, capacity, status).
- **Employees** — add/edit/delete employees; new employees can immediately log in to the Employee Portal using their Employee ID and the default password `user123`.
- **Suppliers** — manage supplier records and the materials they provide.
- **Materials** — add/edit/delete materials; adding a material automatically creates a notification employees will see (with a pop-up) the next time they're in the portal; approve/reject employee purchase requests (auto-deducts stock and notifies the employee).
- **Manufacture** — create and track manufacture/production orders with status, materials used, and dates. Shown on the Dashboard too.
- **Chat** — per-employee chat thread; replies from admin show up instantly in the employee's chat and as a notification-bell pop-up.
- **Notification bell** — shows unread notification + chat counts; dropdown lists the most recent unread items with timestamps.

### Employee / User Portal
- **Dashboard** — quick stats and recently added materials.
- **Notifications** — view all notifications from Admin, filter (all/unread/bookmarked/alert/info/success), mark as seen, reply, and bookmark.
- **Bookmarks** — dedicated page showing only bookmarked notifications.
- **Materials** — browse the materials catalog and submit a purchase request (quantity + material); new materials added by Admin trigger an automatic pop-up notification the moment the employee is in the portal.
- **My Requests** — track the status (Pending/Approved/Rejected) of all purchase requests.
- **Chat with Admin** — a chat box to message the Admin directly; messages appear as a notification (with pop-up + bell badge) on the Admin side.
- **Notification bell** — same behavior as Admin: 3-second pop-up toast on new events, persistent badge count, dropdown notification center.

### Notifications & Pop-ups
- All pop-up toasts (new notification, new material, new chat reply) automatically disappear after **3 seconds**.
- The bell/notification center icon must be clicked to review the full list of notifications at any time.
- Every notification and material shows a **last sent/modified date and time** stamp.

## Features Inherited From Original Login Page
- Password Based and OTP Based login toggle
- CAPTCHA with refresh on click
- Fully responsive design
