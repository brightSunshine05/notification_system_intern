import React, { useState } from 'react';
import LoginPage from './LoginPage';
import AdminPortal from './AdminPortal';
import UserPortal from './UserPortal';
import { getStore, getDefaultStore, saveStore } from './store';

// Initialize store if empty
if (!localStorage.getItem('scms_store')) {
  saveStore(getDefaultStore());
}

export { getStore, saveStore };

export default function App() {
  const [portal, setPortal] = useState(null);
  const [adminLoggedIn, setAdminLoggedIn] = useState(false);
  const [userLoggedIn, setUserLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  const handleSignOut = () => {
    setAdminLoggedIn(false);
    setUserLoggedIn(false);
    setCurrentUser(null);
    setPortal(null);
  };

  if (portal === 'admin') {
    if (!adminLoggedIn) {
      return <LoginPage portalType="admin" onLogin={(u) => { setAdminLoggedIn(true); setCurrentUser(u); }} onBack={() => setPortal(null)} />;
    }
    return <AdminPortal user={currentUser} onSignOut={handleSignOut} />;
  }

  if (portal === 'user') {
    if (!userLoggedIn) {
      return <LoginPage portalType="user" onLogin={(u) => { setUserLoggedIn(true); setCurrentUser(u); }} onBack={() => setPortal(null)} />;
    }
    return <UserPortal user={currentUser} onSignOut={handleSignOut} />;
  }

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #dde1e9 0%, #c5cad6 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 32, padding: 20 }}>
      <div style={{ textAlign: 'center' }}>
        <svg width="72" height="72" viewBox="0 0 64 64" style={{ marginBottom: 14 }}>
          <rect x="4" y="26" width="36" height="22" rx="3" fill="#f57f17" />
          <rect x="4" y="26" width="20" height="22" rx="2" fill="#ff9800" />
          <rect x="36" y="30" width="18" height="18" rx="2" fill="#f57f17" />
          <rect x="38" y="32" width="10" height="8" rx="1" fill="#90caf9" />
          <circle cx="14" cy="50" r="5" fill="#37474f" /><circle cx="14" cy="50" r="2.5" fill="#78909c" />
          <circle cx="44" cy="50" r="5" fill="#37474f" /><circle cx="44" cy="50" r="2.5" fill="#78909c" />
          <path d="M28 12 L22 6 L22 10 L14 10 L14 14 L22 14 L22 18 Z" fill="#4caf50" />
          <path d="M36 20 L42 26 L42 22 L50 22 L50 18 L42 18 L42 14 Z" fill="#4caf50" />
        </svg>
        <h1 style={{ fontSize: 36, fontWeight: 800, color: '#1a237e', letterSpacing: 3 }}>SCMS</h1>
        <p style={{ color: '#718096', fontSize: 15, marginTop: 6 }}>Supply Chain Management System — NIC Portal</p>
      </div>
      <div style={{ display: 'flex', gap: 28, flexWrap: 'wrap', justifyContent: 'center' }}>
        <PortalCard icon="🛡️" title="Admin Portal" desc="Manage materials, employees, stores, inventory, suppliers, manufacturing & notifications" color="#1a237e" accent="#3b82f6" onClick={() => setPortal('admin')} />
        <PortalCard icon="👤" title="Employee Portal" desc="View notifications, purchase materials, bookmark, reply & chat with admin" color="#1b5e20" accent="#22c55e" onClick={() => setPortal('user')} />
      </div>
    </div>
  );
}

function PortalCard({ icon, title, desc, color, accent, onClick }) {
  const [hov, setHov] = useState(false);
  return (
    <div onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ background: '#fff', borderRadius: 20, padding: '40px 36px', width: 310, cursor: 'pointer', boxShadow: hov ? '0 16px 48px rgba(0,0,0,0.18)' : '0 4px 20px rgba(0,0,0,0.10)', transform: hov ? 'translateY(-6px)' : 'none', transition: 'all 0.25s', borderTop: `5px solid ${accent}`, textAlign: 'center' }}>
      <div style={{ fontSize: 52, marginBottom: 16 }}>{icon}</div>
      <h2 style={{ color, fontSize: 22, fontWeight: 700, marginBottom: 10 }}>{title}</h2>
      <p style={{ color: '#718096', fontSize: 13.5, lineHeight: 1.7, marginBottom: 24 }}>{desc}</p>
      <div style={{ background: accent, color: '#fff', borderRadius: 50, padding: '10px 28px', display: 'inline-block', fontWeight: 600, fontSize: 14 }}>Enter Portal →</div>
    </div>
  );
}
