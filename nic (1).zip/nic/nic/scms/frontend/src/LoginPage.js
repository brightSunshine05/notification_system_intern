import React, { useState, useEffect, useRef } from 'react';
import './LoginPage.css';
import { getStore } from './store';

function generateCaptchaText() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = '';
  for (let i = 0; i < 6; i++) result += chars.charAt(Math.floor(Math.random() * chars.length));
  return result;
}

const CaptchaCanvas = ({ text }) => {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    ctx.fillStyle = '#1a237e';
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 80; i++) {
      ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.4})`;
      ctx.fillRect(Math.random() * w, Math.random() * h, 2, 2);
    }
    for (let i = 0; i < 4; i++) {
      ctx.strokeStyle = `rgba(255,255,255,${Math.random() * 0.3 + 0.1})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(Math.random() * w, Math.random() * h);
      ctx.lineTo(Math.random() * w, Math.random() * h);
      ctx.stroke();
    }
    ctx.font = 'bold 28px Arial';
    ctx.textBaseline = 'middle';
    const ls = (w - 20) / text.length;
    for (let i = 0; i < text.length; i++) {
      const colors = ['#ffffff', '#ffeb3b', '#80cbc4', '#ef9a9a'];
      ctx.fillStyle = colors[i % colors.length];
      ctx.save();
      ctx.translate(10 + i * ls + ls / 2, h / 2);
      ctx.rotate((Math.random() - 0.5) * 0.4);
      ctx.fillText(text[i], -8, 0);
      ctx.restore();
    }
  }, [text]);
  return <canvas ref={canvasRef} width={160} height={48} style={{ display: 'block' }} />;
};

const GearIcon = ({ size, color, style }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={style}>
    <path fill={color} d="M43.3 7.5l-2.5 9.4c-2.6 0.8-5 2-7.2 3.5l-9-3.9-9.2 9.2 3.9 9c-1.5 2.2-2.7 4.6-3.5 7.2l-9.4 2.5v13l9.4 2.5c0.8 2.6 2 5 3.5 7.2l-3.9 9 9.2 9.2 9-3.9c2.2 1.5 4.6 2.7 7.2 3.5l2.5 9.4h13l2.5-9.4c2.6-0.8 5-2 7.2-3.5l9 3.9 9.2-9.2-3.9-9c1.5-2.2 2.7-4.6 3.5-7.2l9.4-2.5v-13l-9.4-2.5c-0.8-2.6-2-5-3.5-7.2l3.9-9-9.2-9.2-9 3.9c-2.2-1.5-4.6-2.7-7.2-3.5l-2.5-9.4h-13zm6.5 26c9.1 0 16.5 7.4 16.5 16.5S58.9 66.5 49.8 66.5 33.3 59.1 33.3 50s7.4-16.5 16.5-16.5z" />
  </svg>
);

// Admin credentials
const ADMIN_CREDS = { username: 'TRP_RDD_2301', password: 'Scms@2301' };

export default function LoginPage({ portalType, onLogin, onBack }) {
  const [username, setUsername] = useState(portalType === 'admin' ? 'TRP_RDD_2301' : '');
  const [password, setPassword] = useState('');
  const [captchaInput, setCaptchaInput] = useState('');
  const [captchaText, setCaptchaText] = useState(generateCaptchaText());
  const [error, setError] = useState('');
  const [authMode, setAuthMode] = useState('password');

  const refreshCaptcha = () => { setCaptchaText(generateCaptchaText()); setCaptchaInput(''); };

  const handleSignIn = (e) => {
    e.preventDefault();
    if (captchaInput.toUpperCase() !== captchaText) {
      setError('Captcha does not match. Please try again.');
      refreshCaptcha();
      return;
    }
    if (portalType === 'admin') {
      if (username !== ADMIN_CREDS.username || password !== ADMIN_CREDS.password) {
        setError('Invalid admin credentials.');
        refreshCaptcha();
        return;
      }
      onLogin({ username, name: 'Admin', role: 'admin' });
    } else {
      // User portal: check employees list
      const store = getStore();
      const emp = store.employees.find(e => e.empId === username && e.status === 'Active');
      if (!emp) {
        setError('Employee ID not found or account inactive. Contact Admin.');
        refreshCaptcha();
        return;
      }
      if (password !== 'user123') {
        setError('Invalid password. Default: user123');
        refreshCaptcha();
        return;
      }
      onLogin({ username: emp.empId, name: emp.name, role: 'user', empId: emp.empId, department: emp.department });
    }
  };

  const isAdmin = portalType === 'admin';
  const accentColor = isAdmin ? '#1a237e' : '#1b5e20';
  const btnColor = isAdmin ? '#3b82f6' : '#22c55e';

  return (
    <div className="page-wrapper">
      <div className="card">
        <div className="left-panel">
          <div className="logo-area">
            <div className="logo-icon">
              <svg width="64" height="64" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
                <rect x="4" y="26" width="36" height="22" rx="3" fill="#f57f17" />
                <rect x="4" y="26" width="20" height="22" rx="2" fill="#ff9800" />
                <rect x="36" y="30" width="18" height="18" rx="2" fill="#f57f17" />
                <rect x="38" y="32" width="10" height="8" rx="1" fill="#90caf9" />
                <circle cx="14" cy="50" r="5" fill="#37474f" /><circle cx="14" cy="50" r="2.5" fill="#78909c" />
                <circle cx="44" cy="50" r="5" fill="#37474f" /><circle cx="44" cy="50" r="2.5" fill="#78909c" />
              </svg>
            </div>
          </div>
          <h1 className="sign-in-title">Sign in</h1>
          <p className="sign-in-sub">
            {isAdmin ? '🛡️ Admin Portal — ' : '👤 Employee Portal — '}
            <span className="scms-brand">SCMS</span>
          </p>
          {!isAdmin && (
            <div className="new-user-banner" style={{ background: '#e8f5e9', borderColor: '#388e3c', color: '#1b5e20' }}>
              👷 Use your <strong>Employee ID</strong> (e.g. EMP-0001) as username and <strong>user123</strong> as password.
            </div>
          )}
          <div className="auth-toggle">
            <label className="radio-label">
              <input type="radio" name="authMode" value="password" checked={authMode === 'password'} onChange={() => setAuthMode('password')} />
              <span className="radio-custom"></span> Password Based
            </label>
            <label className="radio-label">
              <input type="radio" name="authMode" value="otp" checked={authMode === 'otp'} onChange={() => setAuthMode('otp')} />
              <span className="radio-custom"></span> OTP Based
            </label>
          </div>
          <form className="login-form" onSubmit={handleSignIn}>
            <input type="text" className="form-input" placeholder={isAdmin ? 'Admin Username' : 'Employee ID (e.g. EMP-0001)'}
              value={username} onChange={e => setUsername(e.target.value)} />
            {authMode === 'password' ? (
              <input type="password" className="form-input" placeholder="Password"
                value={password} onChange={e => setPassword(e.target.value)} />
            ) : (
              <input type="text" className="form-input" placeholder="Enter OTP" />
            )}
            <div className="captcha-row">
              <div className="captcha-box" onClick={refreshCaptcha} title="Click to refresh" style={{ cursor: 'pointer' }}>
                <CaptchaCanvas text={captchaText} />
              </div>
              <input type="text" className="captcha-input" placeholder="Enter Captcha"
                value={captchaInput} onChange={e => setCaptchaInput(e.target.value)} />
            </div>
            <p className="captcha-hint">Can't read? Click image to refresh.</p>
            {error && <p className="error-msg">{error}</p>}
            <button type="submit" className="sign-in-btn" style={{ background: btnColor }}>Sign in</button>
            <button type="button" className="know-more-btn" style={{ marginTop: 4, width: '100%' }} onClick={onBack}>← Back to Portal Selection</button>
          </form>
        </div>
        <div className="divider" />
        <div className="right-panel">
          <div className="gears-container">
            <div className="gear gear-center"><GearIcon size={130} color="#d4956a" /></div>
            <div className="gear gear-top-left"><GearIcon size={70} color="#4db6ac" /></div>
            <div className="gear gear-top-right"><GearIcon size={60} color="#4db6ac" /></div>
            <div className="gear gear-bottom-right"><GearIcon size={75} color="#4db6ac" /></div>
          </div>
          <h2 className="config-title">{isAdmin ? 'Admin Access' : 'Employee Access'}</h2>
          <p className="config-desc">
            {isAdmin
              ? 'Manage stores, employees, materials, inventory, suppliers & notifications.'
              : 'View notifications, purchase materials, bookmark messages & chat with admin.'}
          </p>
        </div>
      </div>
    </div>
  );
}
