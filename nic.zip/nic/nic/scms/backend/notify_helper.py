import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

logger = logging.getLogger(__name__)


async def send_notification(
    db: AsyncSession,
    user_id: int,
    message: str,
    title: str = "Notification",
    notif_type: str = "info",
) -> None:
    """Insert a row into public.notifications.
    Matches the reference project's pattern (asyncpg INSERT via text()),
    extended with title + type to support the richer NIC SCMS table.
    """
    try:
        await db.execute(
            text(
                "INSERT INTO public.notifications "
                "(user_id, title, message, type, bookmarked_by, replies) "
                "VALUES (:uid, :title, :msg, :type, '{}', '[]'::jsonb)"
            ),
            {"uid": user_id, "title": title, "msg": message, "type": notif_type},
        )
        await db.commit()
        logger.info(f"Notification → user {user_id}: {message}")
    except Exception as e:
        logger.error(f"Notification failed: {e}")
