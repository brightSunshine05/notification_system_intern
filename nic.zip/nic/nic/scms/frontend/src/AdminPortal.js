import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  getStore, formatTime, timeAgo,
  apiSendNotification, apiMarkAllRead, apiDeleteNotif, apiReplyNotif,
  apiAddEmployee, apiUpdateEmployee, apiDeleteEmployee,
  apiAddMaterial, apiUpdateMaterial, apiDeleteMaterial,
  apiAddStore, apiUpdateStore, apiDeleteStore,
  apiAddSupplier, apiUpdateSupplier, apiDeleteSupplier,
  apiAddInventory, apiUpdateInventory, apiDeleteInventory,
  apiAddManufacture, apiUpdateManufacture, apiDeleteManufacture,
  apiSendChat, apiMarkAdminRead,
  apiApprovePurchase, apiRejectPurchase,
} from './store';
import './Portal.css';

const SIDEBAR_ITEMS = [
  { key: 'dashboard',     icon: '🏠', label: 'Dashboard' },
  { key: 'notifications', icon: '🔔', label: 'Notifications' },
  { key: 'inventory',     icon: '📦', label: 'Inventory' },
  { key: 'stores',        icon: '🏪', label: 'Stores' },
  { key: 'employees',     icon: '👷', label: 'Employees' },
  { key: 'suppliers',     icon: '🚚', label: 'Suppliers' },
  { key: 'materials',     icon: '🧱', label: 'Materials' },
  { key: 'manufacture',   icon: '🏭', label: 'Manufacture' },
  { key: 'chat',          icon: '💬', label: 'Chat' },
];

export default function AdminPortal({ user, onSignOut }) {
  const [section, setSection] = useState('dashboard');
  const [store, setStore]     = useState({ notifications: [], materials: [], employees: [], stores: [], suppliers: [], inventory: [], manufacture: [], chatMessages: [], purchaseRequests: [] });
  const [popup, setPopup]     = useState(null);
  const [bellOpen, setBellOpen] = useState(false);

  const reload = useCallback(async () => {
    try { setStore(await getStore()); } catch {}
  }, []);

  useEffect(() => {
    reload();
    const iv = setInterval(reload, 3000);
    return () => clearInterval(iv);
  }, [reload]);

  const showPopup = (message, type = 'success') => {
    setPopup({ message, type });
    setTimeout(() => setPopup(null), 3000);
  };

  const unreadNotif = store.notifications?.filter(n => !n.read).length || 0;
  const unreadChat  = store.chatMessages?.filter(m => !m.readByAdmin && m.from !== 'Admin').length || 0;

  return (
    <div className="portal-shell">
      {popup && (
        <div className={`popup-toast popup-${popup.type}`}>
          {popup.type === 'success' ? '✅' : popup.type === 'error' ? '❌' : 'ℹ️'} {popup.message}
        </div>
      )}
      <aside className="portal-sidebar sidebar-admin">
        <div className="portal-logo">
          <svg width="32" height="32" viewBox="0 0 64 64">
            <rect x="4" y="26" width="36" height="22" rx="3" fill="#f57f17" />
            <rect x="4" y="26" width="20" height="22" rx="2" fill="#ff9800" />
            <rect x="36" y="30" width="18" height="18" rx="2" fill="#f57f17" />
            <rect x="38" y="32" width="10" height="8" rx="1" fill="#90caf9" />
            <circle cx="14" cy="50" r="5" fill="#37474f" /><circle cx="14" cy="50" r="2.5" fill="#78909c" />
            <circle cx="44" cy="50" r="5" fill="#37474f" /><circle cx="44" cy="50" r="2.5" fill="#78909c" />
          </svg>
          <span className="portal-logo-text">SCMS</span>
          <span style={{ fontSize: 10, background: '#3b82f6', color: '#fff', borderRadius: 4, padding: '1px 6px', marginLeft: 4 }}>ADMIN</span>
        </div>
        <nav className="portal-nav">
          {SIDEBAR_ITEMS.map(item => (
            <div key={item.key} className={`portal-nav-item ${section === item.key ? 'portal-nav-active' : ''}`} onClick={() => setSection(item.key)}>
              <span className="portal-nav-icon">{item.icon}</span>
              <span>{item.label}</span>
              {item.key === 'notifications' && unreadNotif > 0 && <span className="portal-badge">{unreadNotif}</span>}
              {item.key === 'chat' && unreadChat > 0 && <span className="portal-badge" style={{ background: '#f59e0b' }}>{unreadChat}</span>}
            </div>
          ))}
        </nav>
        <div className="portal-sidebar-footer">
          <div className="portal-user-chip">
            <div className="portal-avatar" style={{ background: '#3b82f6' }}>A</div>
            <div className="portal-user-info">
              <span className="portal-user-name">{user?.username || 'Admin'}</span>
              <span className="portal-user-role">Administrator</span>
            </div>
          </div>
          <button className="portal-signout" onClick={onSignOut}>Sign Out</button>
        </div>
      </aside>

      <main className="portal-main">
        <header className="portal-header">
          <div>
            <h1 className="portal-page-title">{SIDEBAR_ITEMS.find(i => i.key === section)?.label || 'Dashboard'}</h1>
            <p className="portal-page-sub">Admin Portal — {new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
          </div>
          <div style={{ position: 'relative' }}>
            <button className="bell-btn" onClick={() => setBellOpen(o => !o)}>
              🔔{(unreadNotif + unreadChat) > 0 && <span className="bell-count">{unreadNotif + unreadChat}</span>}
            </button>
            {bellOpen && (
              <div className="bell-dropdown">
                <div className="bell-header">Notification Center</div>
                {store.chatMessages?.filter(m => !m.readByAdmin && m.from !== 'Admin').slice(0, 5).map(m => (
                  <div key={m.id} className="bell-item bell-chat">💬 <strong>{m.from}</strong>: {m.message?.slice(0, 60)}…<div style={{ fontSize: 10, color: '#888', marginTop: 2 }}>{formatTime(m.time)}</div></div>
                ))}
                {store.notifications?.filter(n => !n.read).slice(0, 5).map(n => (
                  <div key={n.id} className="bell-item">🔔 <strong>{n.title}</strong>: {n.message?.slice(0, 50)}…<div style={{ fontSize: 10, color: '#888', marginTop: 2 }}>{formatTime(n.time)}</div></div>
                ))}
                {(unreadNotif + unreadChat) === 0 && <div style={{ padding: 16, color: '#888', textAlign: 'center' }}>All caught up!</div>}
              </div>
            )}
          </div>
        </header>
        <div className="portal-content">
          {section === 'dashboard'     && <AdminDashboard store={store} setSection={setSection} />}
          {section === 'notifications' && <AdminNotifications store={store} reload={reload} showPopup={showPopup} />}
          {section === 'inventory'     && <AdminInventory store={store} reload={reload} showPopup={showPopup} />}
          {section === 'stores'        && <AdminStores store={store} reload={reload} showPopup={showPopup} />}
          {section === 'employees'     && <AdminEmployees store={store} reload={reload} showPopup={showPopup} />}
          {section === 'suppliers'     && <AdminSuppliers store={store} reload={reload} showPopup={showPopup} />}
          {section === 'materials'     && <AdminMaterials store={store} reload={reload} showPopup={showPopup} />}
          {section === 'manufacture'   && <AdminManufacture store={store} reload={reload} showPopup={showPopup} />}
          {section === 'chat'          && <AdminChat store={store} reload={reload} user={user} />}
        </div>
      </main>
    </div>
  );
}

// ── DASHBOARD ─────────────────────────────────────────────────────────────────
function AdminDashboard({ store, setSection }) {
  const stats = [
    { label: 'Employees',       value: store.employees?.length || 0,     icon: '👷', color: '#3b82f6', key: 'employees' },
    { label: 'Materials',       value: store.materials?.length || 0,     icon: '🧱', color: '#8b5cf6', key: 'materials' },
    { label: 'Inventory Items', value: store.inventory?.length || 0,     icon: '📦', color: '#f59e0b', key: 'inventory' },
    { label: 'Stores',          value: store.stores?.length || 0,        icon: '🏪', color: '#10b981', key: 'stores' },
    { label: 'Suppliers',       value: store.suppliers?.length || 0,     icon: '🚚', color: '#ef4444', key: 'suppliers' },
    { label: 'Manufacture Orders', value: store.manufacture?.length || 0,icon: '🏭', color: '#f97316', key: 'manufacture' },
    { label: 'Notifications',   value: store.notifications?.length || 0, icon: '🔔', color: '#06b6d4', key: 'notifications' },
    { label: 'Pending Requests', value: store.purchaseRequests?.filter(r => r.status === 'Pending').length || 0, icon: '📋', color: '#d946ef', key: 'materials' },
  ];
  const lowStock = store.inventory?.filter(i => i.quantity < i.minQty) || [];
  return (
    <div>
      <div className="stat-grid">
        {stats.map(s => (
          <div key={s.label} className="stat-card" style={{ borderTop: `4px solid ${s.color}`, cursor: 'pointer' }} onClick={() => setSection(s.key)}>
            <span style={{ fontSize: 28 }}>{s.icon}</span>
            <span className="stat-value" style={{ color: s.color }}>{s.value}</span>
            <span className="stat-label">{s.label}</span>
          </div>
        ))}
      </div>
      <div className="section-card" style={{ marginTop: 24 }}>
        <h3 className="section-title">🏭 Manufacture Orders Overview</h3>
        <table className="data-table">
          <thead><tr><th>Order ID</th><th>Product</th><th>Qty</th><th>Status</th><th>Start Date</th></tr></thead>
          <tbody>
            {(store.manufacture || []).map(m => (
              <tr key={m.id}><td><span className="badge badge-blue">{m.orderId}</span></td><td>{m.product}</td><td>{m.quantity}</td>
                <td><span className={`badge ${m.status === 'Completed' ? 'badge-green' : m.status === 'In Progress' ? 'badge-yellow' : 'badge-red'}`}>{m.status}</span></td>
                <td>{formatTime(m.startDate)}</td></tr>
            ))}
            {!store.manufacture?.length && <tr><td colSpan={5} style={{ textAlign: 'center', color: '#aaa', padding: 24 }}>No orders yet</td></tr>}
          </tbody>
        </table>
      </div>
      {lowStock.length > 0 && (
        <div className="section-card" style={{ marginTop: 16, borderLeft: '4px solid #ef4444' }}>
          <h3 className="section-title" style={{ color: '#ef4444' }}>⚠️ Low Stock Alerts ({lowStock.length})</h3>
          {lowStock.map(i => (
            <div key={i.id} style={{ padding: '8px 0', borderBottom: '1px solid #f3f4f6', fontSize: 14 }}>
              <strong>{i.name}</strong> — {i.quantity} {i.unit} (min: {i.minQty}) @ {i.location}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── NOTIFICATIONS ─────────────────────────────────────────────────────────────
function AdminNotifications({ store, reload, showPopup }) {
  const [title, setTitle]   = useState('');
  const [message, setMessage] = useState('');
  const [type, setType]     = useState('info');

  const send = async () => {
    if (!title.trim() || !message.trim()) { showPopup('Title and message required', 'error'); return; }
    try {
      await apiSendNotification(title.trim(), message.trim(), type, 0); // 0 = broadcast
      setTitle(''); setMessage('');
      await reload();
      showPopup('Notification sent to all users!');
    } catch (e) { showPopup(e.message, 'error'); }
  };

  const del = async (id) => {
    try { await apiDeleteNotif(id); await reload(); } catch {}
  };

  const markAllRead = async () => {
    try { await apiMarkAllRead(0); await reload(); } catch {} // 0 = all
  };

  return (
    <div>
      <div className="section-card">
        <h3 className="section-title">📤 Send Notification to All Users</h3>
        <div className="form-row">
          <select className="form-select" value={type} onChange={e => setType(e.target.value)}>
            <option value="info">ℹ️ Info</option><option value="alert">⚠️ Alert</option><option value="success">✅ Success</option>
          </select>
          <input className="form-input-sm" placeholder="Notification Title" value={title} onChange={e => setTitle(e.target.value)} />
        </div>
        <textarea className="form-textarea" placeholder="Notification message…" rows={3} value={message} onChange={e => setMessage(e.target.value)} />
        <button className="btn btn-primary" onClick={send}>📨 Send Notification</button>
      </div>
      <div className="section-card" style={{ marginTop: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h3 className="section-title" style={{ margin: 0 }}>📋 All Notifications ({store.notifications?.length || 0})</h3>
          <button className="btn btn-sm" onClick={markAllRead}>✓ Mark All Read</button>
        </div>
        {(store.notifications || []).map(n => (
          <div key={n.id} className={`notif-item notif-${n.type} ${!n.read ? 'notif-unread' : ''}`}>
            <div className="notif-top">
              <span className="notif-title">{n.title}</span>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <span className={`badge badge-${n.type === 'info' ? 'blue' : n.type === 'alert' ? 'red' : 'green'}`}>{n.type}</span>
                <span style={{ fontSize: 11, color: '#888' }}>{formatTime(n.time)}</span>
                <button className="icon-btn" onClick={() => del(n.id)}>🗑️</button>
              </div>
            </div>
            <p style={{ fontSize: 14, color: '#4b5563', margin: '4px 0 8px' }}>{n.message}</p>
            {n.replies?.length > 0 && (
              <div style={{ background: '#f0f4ff', borderRadius: 8, padding: 10, marginTop: 8 }}>
                <strong style={{ fontSize: 12, color: '#6366f1' }}>💬 Replies:</strong>
                {n.replies.map((r, i) => (
                  <div key={i} style={{ fontSize: 13, marginTop: 4, color: '#374151' }}>
                    <strong>{r.from}:</strong> {r.message} <span style={{ color: '#9ca3af', fontSize: 11 }}>— {formatTime(r.time)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
        {!store.notifications?.length && <div className="empty-state">No notifications yet</div>}
      </div>
    </div>
  );
}

// ── INVENTORY ─────────────────────────────────────────────────────────────────
function AdminInventory({ store, reload, showPopup }) {
  const empty = { itemCode: '', name: '', category: '', quantity: '', minQty: '', unit: 'pcs', location: '', supplier: '' };
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);

  const save = async () => {
    if (!form.name.trim() || !form.itemCode.trim()) { showPopup('Item code and name required', 'error'); return; }
    const payload = { item_code: form.itemCode, name: form.name, category: form.category, quantity: +form.quantity, min_qty: +form.minQty, unit: form.unit, location: form.location, supplier: form.supplier };
    try {
      if (editing !== null) { await apiUpdateInventory(editing, payload); showPopup('Inventory item updated!'); }
      else { await apiAddInventory(payload); showPopup('Inventory item added!'); }
      setForm(empty); setEditing(null); await reload();
    } catch (e) { showPopup(e.message, 'error'); }
  };

  return (
    <div>
      <div className="section-card">
        <h3 className="section-title">{editing ? '✏️ Edit Item' : '➕ Add Inventory Item'}</h3>
        <div className="form-grid">
          <input className="form-input-sm" placeholder="Item Code"       value={form.itemCode}  onChange={e => setForm({ ...form, itemCode: e.target.value })} />
          <input className="form-input-sm" placeholder="Item Name"       value={form.name}      onChange={e => setForm({ ...form, name: e.target.value })} />
          <input className="form-input-sm" placeholder="Category"        value={form.category}  onChange={e => setForm({ ...form, category: e.target.value })} />
          <input className="form-input-sm" placeholder="Quantity" type="number" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} />
          <input className="form-input-sm" placeholder="Min Quantity" type="number" value={form.minQty} onChange={e => setForm({ ...form, minQty: e.target.value })} />
          <input className="form-input-sm" placeholder="Unit (pcs/kg/liters)" value={form.unit}  onChange={e => setForm({ ...form, unit: e.target.value })} />
          <input className="form-input-sm" placeholder="Location/Store"  value={form.location}  onChange={e => setForm({ ...form, location: e.target.value })} />
          <input className="form-input-sm" placeholder="Supplier"        value={form.supplier}  onChange={e => setForm({ ...form, supplier: e.target.value })} />
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <button className="btn btn-primary" onClick={save}>{editing ? '💾 Update' : '➕ Add Item'}</button>
          {editing && <button className="btn btn-secondary" onClick={() => { setForm(empty); setEditing(null); }}>Cancel</button>}
        </div>
      </div>
      <div className="section-card" style={{ marginTop: 16 }}>
        <h3 className="section-title">📦 Inventory List</h3>
        <table className="data-table">
          <thead><tr><th>Code</th><th>Name</th><th>Category</th><th>Qty</th><th>Min</th><th>Unit</th><th>Location</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {(store.inventory || []).map(i => (
              <tr key={i.id}>
                <td><span className="badge badge-blue">{i.itemCode}</span></td>
                <td>{i.name}</td><td>{i.category}</td>
                <td style={{ color: i.quantity < i.minQty ? '#ef4444' : 'inherit', fontWeight: i.quantity < i.minQty ? 700 : 400 }}>{i.quantity}</td>
                <td>{i.minQty}</td><td>{i.unit}</td><td>{i.location}</td>
                <td><span className={`badge ${i.quantity < i.minQty ? 'badge-red' : 'badge-green'}`}>{i.quantity < i.minQty ? 'Low Stock' : 'OK'}</span></td>
                <td>
                  <button className="icon-btn" onClick={() => { setForm({ itemCode: i.itemCode, name: i.name, category: i.category, quantity: i.quantity, minQty: i.minQty, unit: i.unit, location: i.location, supplier: i.supplier }); setEditing(i.id); }}>✏️</button>
                  <button className="icon-btn" onClick={async () => { await apiDeleteInventory(i.id); await reload(); showPopup('Item removed'); }}>🗑️</button>
                </td>
              </tr>
            ))}
            {!store.inventory?.length && <tr><td colSpan={9} className="empty-cell">No inventory items</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── STORES ────────────────────────────────────────────────────────────────────
function AdminStores({ store, reload, showPopup }) {
  const empty = { storeId: '', name: '', location: '', manager: '', capacity: '', status: 'Active' };
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);

  const save = async () => {
    if (!form.storeId.trim() || !form.name.trim()) { showPopup('Store ID and name required', 'error'); return; }
    const payload = { store_id: form.storeId, name: form.name, location: form.location, manager: form.manager, capacity: +form.capacity, status: form.status };
    try {
      if (editing) { await apiUpdateStore(editing, payload); showPopup('Store updated!'); }
      else { await apiAddStore(payload); showPopup('Store added!'); }
      setForm(empty); setEditing(null); await reload();
    } catch (e) { showPopup(e.message, 'error'); }
  };

  return (
    <div>
      <div className="section-card">
        <h3 className="section-title">{editing ? '✏️ Edit Store' : '➕ Add Store'}</h3>
        <div className="form-grid">
          <input className="form-input-sm" placeholder="Store ID (e.g. STR-003)"     value={form.storeId}  onChange={e => setForm({ ...form, storeId: e.target.value })} />
          <input className="form-input-sm" placeholder="Store Name"                  value={form.name}     onChange={e => setForm({ ...form, name: e.target.value })} />
          <input className="form-input-sm" placeholder="Location"                    value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} />
          <input className="form-input-sm" placeholder="Manager Name"                value={form.manager}  onChange={e => setForm({ ...form, manager: e.target.value })} />
          <input className="form-input-sm" placeholder="Capacity" type="number"      value={form.capacity} onChange={e => setForm({ ...form, capacity: e.target.value })} />
          <select className="form-select"  value={form.status}   onChange={e => setForm({ ...form, status: e.target.value })}>
            <option>Active</option><option>Inactive</option><option>Under Maintenance</option>
          </select>
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <button className="btn btn-primary" onClick={save}>{editing ? '💾 Update' : '➕ Add Store'}</button>
          {editing && <button className="btn btn-secondary" onClick={() => { setForm(empty); setEditing(null); }}>Cancel</button>}
        </div>
      </div>
      <div className="section-card" style={{ marginTop: 16 }}>
        <h3 className="section-title">🏪 All Stores</h3>
        <table className="data-table">
          <thead><tr><th>ID</th><th>Name</th><th>Location</th><th>Manager</th><th>Capacity</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {(store.stores || []).map(s => (
              <tr key={s.id}>
                <td><span className="badge badge-blue">{s.storeId}</span></td>
                <td>{s.name}</td><td>{s.location}</td><td>{s.manager}</td><td>{s.capacity}</td>
                <td><span className={`badge ${s.status === 'Active' ? 'badge-green' : 'badge-red'}`}>{s.status}</span></td>
                <td>
                  <button className="icon-btn" onClick={() => { setForm({ storeId: s.storeId, name: s.name, location: s.location, manager: s.manager, capacity: s.capacity, status: s.status }); setEditing(s.id); }}>✏️</button>
                  <button className="icon-btn" onClick={async () => { await apiDeleteStore(s.id); await reload(); showPopup('Store removed'); }}>🗑️</button>
                </td>
              </tr>
            ))}
            {!store.stores?.length && <tr><td colSpan={7} className="empty-cell">No stores</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── EMPLOYEES ─────────────────────────────────────────────────────────────────
function AdminEmployees({ store, reload, showPopup }) {
  const empty = { empId: '', name: '', department: '', email: '', phone: '', status: 'Active' };
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);

  const save = async () => {
    if (!form.empId.trim() || !form.name.trim()) { showPopup('Employee ID and name required', 'error'); return; }
    const payload = { emp_id: form.empId, name: form.name, department: form.department, email: form.email, phone: form.phone, status: form.status };
    try {
      if (editing) { await apiUpdateEmployee(editing, payload); showPopup('Employee updated!'); }
      else { await apiAddEmployee(payload); showPopup('Employee added!'); }
      setForm(empty); setEditing(null); await reload();
    } catch (e) { showPopup(e.message, 'error'); }
  };

  return (
    <div>
      <div className="section-card">
        <h3 className="section-title">{editing ? '✏️ Edit Employee' : '➕ Add Employee'}</h3>
        <div className="form-grid">
          <input className="form-input-sm" placeholder="Employee ID (e.g. EMP-0002)" value={form.empId}      onChange={e => setForm({ ...form, empId: e.target.value })} />
          <input className="form-input-sm" placeholder="Full Name"                   value={form.name}       onChange={e => setForm({ ...form, name: e.target.value })} />
          <input className="form-input-sm" placeholder="Department"                  value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} />
          <input className="form-input-sm" placeholder="Email"                       value={form.email}      onChange={e => setForm({ ...form, email: e.target.value })} />
          <input className="form-input-sm" placeholder="Phone"                       value={form.phone}      onChange={e => setForm({ ...form, phone: e.target.value })} />
          <select className="form-select"  value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
            <option>Active</option><option>Inactive</option>
          </select>
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <button className="btn btn-primary" onClick={save}>{editing ? '💾 Update' : '➕ Add Employee'}</button>
          {editing && <button className="btn btn-secondary" onClick={() => { setForm(empty); setEditing(null); }}>Cancel</button>}
        </div>
      </div>
      <div className="section-card" style={{ marginTop: 16 }}>
        <h3 className="section-title">👷 All Employees ({store.employees?.length || 0})</h3>
        <table className="data-table">
          <thead><tr><th>Emp ID</th><th>Name</th><th>Department</th><th>Email</th><th>Phone</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
          <tbody>
            {(store.employees || []).map(e => (
              <tr key={e.id}>
                <td><span className="badge badge-blue">{e.empId}</span></td>
                <td>{e.name}</td><td>{e.department}</td><td>{e.email}</td><td>{e.phone}</td>
                <td><span className={`badge ${e.status === 'Active' ? 'badge-green' : 'badge-red'}`}>{e.status}</span></td>
                <td style={{ fontSize: 12 }}>{formatTime(e.joinedAt)}</td>
                <td>
                  <button className="icon-btn" onClick={() => { setForm({ empId: e.empId, name: e.name, department: e.department, email: e.email, phone: e.phone, status: e.status }); setEditing(e.id); }}>✏️</button>
                  <button className="icon-btn" onClick={async () => { await apiDeleteEmployee(e.id); await reload(); showPopup('Employee removed'); }}>🗑️</button>
                </td>
              </tr>
            ))}
            {!store.employees?.length && <tr><td colSpan={8} className="empty-cell">No employees</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── SUPPLIERS ─────────────────────────────────────────────────────────────────
function AdminSuppliers({ store, reload, showPopup }) {
  const empty = { supplierId: '', name: '', contact: '', phone: '', email: '', materials: '', status: 'Active' };
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);

  const save = async () => {
    if (!form.supplierId.trim() || !form.name.trim()) { showPopup('Supplier ID and name required', 'error'); return; }
    const payload = { supplier_id: form.supplierId, name: form.name, contact: form.contact, phone: form.phone, email: form.email, materials: form.materials, status: form.status };
    try {
      if (editing) { await apiUpdateSupplier(editing, payload); showPopup('Supplier updated!'); }
      else { await apiAddSupplier(payload); showPopup('Supplier added!'); }
      setForm(empty); setEditing(null); await reload();
    } catch (e) { showPopup(e.message, 'error'); }
  };

  return (
    <div>
      <div className="section-card">
        <h3 className="section-title">{editing ? '✏️ Edit Supplier' : '➕ Add Supplier'}</h3>
        <div className="form-grid">
          <input className="form-input-sm" placeholder="Supplier ID (e.g. SUP-002)" value={form.supplierId} onChange={e => setForm({ ...form, supplierId: e.target.value })} />
          <input className="form-input-sm" placeholder="Supplier Name"              value={form.name}       onChange={e => setForm({ ...form, name: e.target.value })} />
          <input className="form-input-sm" placeholder="Contact Person"             value={form.contact}    onChange={e => setForm({ ...form, contact: e.target.value })} />
          <input className="form-input-sm" placeholder="Phone"                      value={form.phone}      onChange={e => setForm({ ...form, phone: e.target.value })} />
          <input className="form-input-sm" placeholder="Email"                      value={form.email}      onChange={e => setForm({ ...form, email: e.target.value })} />
          <input className="form-input-sm" placeholder="Materials Supplied"         value={form.materials}  onChange={e => setForm({ ...form, materials: e.target.value })} />
          <select className="form-select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
            <option>Active</option><option>Inactive</option>
          </select>
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <button className="btn btn-primary" onClick={save}>{editing ? '💾 Update' : '➕ Add Supplier'}</button>
          {editing && <button className="btn btn-secondary" onClick={() => { setForm(empty); setEditing(null); }}>Cancel</button>}
        </div>
      </div>
      <div className="section-card" style={{ marginTop: 16 }}>
        <h3 className="section-title">🚚 All Suppliers</h3>
        <table className="data-table">
          <thead><tr><th>ID</th><th>Name</th><th>Contact</th><th>Phone</th><th>Email</th><th>Materials</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {(store.suppliers || []).map(s => (
              <tr key={s.id}>
                <td><span className="badge badge-blue">{s.supplierId}</span></td>
                <td>{s.name}</td><td>{s.contact}</td><td>{s.phone}</td><td>{s.email}</td><td>{s.materials}</td>
                <td><span className={`badge ${s.status === 'Active' ? 'badge-green' : 'badge-red'}`}>{s.status}</span></td>
                <td>
                  <button className="icon-btn" onClick={() => { setForm({ supplierId: s.supplierId, name: s.name, contact: s.contact, phone: s.phone, email: s.email, materials: s.materials, status: s.status }); setEditing(s.id); }}>✏️</button>
                  <button className="icon-btn" onClick={async () => { await apiDeleteSupplier(s.id); await reload(); showPopup('Supplier removed'); }}>🗑️</button>
                </td>
              </tr>
            ))}
            {!store.suppliers?.length && <tr><td colSpan={8} className="empty-cell">No suppliers</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── MATERIALS ─────────────────────────────────────────────────────────────────
function AdminMaterials({ store, reload, showPopup }) {
  const empty = { name: '', category: '', quantity: '', unit: 'pcs', price: '', description: '' };
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);

  const save = async () => {
    if (!form.name.trim()) { showPopup('Material name required', 'error'); return; }
    const payload = { name: form.name, category: form.category, quantity: +form.quantity, unit: form.unit, price: +form.price, description: form.description };
    try {
      if (editing) { await apiUpdateMaterial(editing, payload); showPopup('Material updated — users notified!'); }
      else { await apiAddMaterial(payload); showPopup('Material added! All users notified automatically.'); }
      setForm(empty); setEditing(null); await reload();
    } catch (e) { showPopup(e.message, 'error'); }
  };

  const handleApprove = async (req) => {
    try { await apiApprovePurchase(req.id); await reload(); showPopup('Request approved & user notified!'); }
    catch (e) { showPopup(e.message, 'error'); }
  };

  const handleReject = async (req) => {
    try { await apiRejectPurchase(req.id); await reload(); showPopup('Request rejected.'); }
    catch (e) { showPopup(e.message, 'error'); }
  };

  const pendingReqs = (store.purchaseRequests || []).filter(r => r.status === 'Pending');

  return (
    <div>
      <div className="section-card">
        <h3 className="section-title">{editing ? '✏️ Edit Material' : '➕ Add Material'}</h3>
        <div className="form-grid">
          <input className="form-input-sm" placeholder="Material Name"          value={form.name}        onChange={e => setForm({ ...form, name: e.target.value })} />
          <input className="form-input-sm" placeholder="Category"               value={form.category}    onChange={e => setForm({ ...form, category: e.target.value })} />
          <input className="form-input-sm" placeholder="Quantity" type="number" value={form.quantity}    onChange={e => setForm({ ...form, quantity: e.target.value })} />
          <input className="form-input-sm" placeholder="Unit"                   value={form.unit}        onChange={e => setForm({ ...form, unit: e.target.value })} />
          <input className="form-input-sm" placeholder="Price (₹)" type="number" value={form.price}     onChange={e => setForm({ ...form, price: e.target.value })} />
          <input className="form-input-sm" placeholder="Description"            value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <button className="btn btn-primary" onClick={save}>{editing ? '💾 Update' : '➕ Add Material'}</button>
          {editing && <button className="btn btn-secondary" onClick={() => { setForm(empty); setEditing(null); }}>Cancel</button>}
        </div>
      </div>

      {pendingReqs.length > 0 && (
        <div className="section-card" style={{ marginTop: 16, borderLeft: '4px solid #f59e0b' }}>
          <h3 className="section-title" style={{ color: '#d97706' }}>⏳ Pending Purchase Requests ({pendingReqs.length})</h3>
          {pendingReqs.map(r => (
            <div key={r.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f3f4f6' }}>
              <div>
                <strong>{r.userName || r.userId}</strong> wants <strong>{r.quantity} {r.materialName}</strong>
                <div style={{ fontSize: 12, color: '#888' }}>{formatTime(r.time)}</div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-primary btn-sm" onClick={() => handleApprove(r)}>✅ Approve</button>
                <button className="btn btn-danger btn-sm" onClick={() => handleReject(r)}>❌ Reject</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="section-card" style={{ marginTop: 16 }}>
        <h3 className="section-title">🧱 Materials Catalog ({store.materials?.length || 0})</h3>
        <table className="data-table">
          <thead><tr><th>Name</th><th>Category</th><th>Qty</th><th>Unit</th><th>Price</th><th>Added</th><th>Actions</th></tr></thead>
          <tbody>
            {(store.materials || []).map(m => (
              <tr key={m.id}>
                <td><strong>{m.name}</strong></td><td>{m.category}</td><td>{m.quantity}</td><td>{m.unit}</td><td>₹{m.price}</td>
                <td style={{ fontSize: 12 }}>{formatTime(m.addedAt)}</td>
                <td>
                  <button className="icon-btn" onClick={() => { setForm({ name: m.name, category: m.category || '', quantity: m.quantity, unit: m.unit, price: m.price, description: m.description || '' }); setEditing(m.id); }}>✏️</button>
                  <button className="icon-btn" onClick={async () => { await apiDeleteMaterial(m.id); await reload(); showPopup('Material removed'); }}>🗑️</button>
                </td>
              </tr>
            ))}
            {!store.materials?.length && <tr><td colSpan={7} className="empty-cell">No materials</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── MANUFACTURE ───────────────────────────────────────────────────────────────
function AdminManufacture({ store, reload, showPopup }) {
  const empty = { orderId: '', product: '', quantity: '', status: 'Planned', materials: '' };
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);

  const save = async () => {
    if (!form.orderId.trim() || !form.product.trim()) { showPopup('Order ID and product required', 'error'); return; }
    const payload = { order_id: form.orderId, product: form.product, quantity: +form.quantity, status: form.status, materials: form.materials ? form.materials.split(',').map(s => s.trim()) : [] };
    try {
      if (editing) { await apiUpdateManufacture(editing, payload); showPopup('Order updated!'); }
      else { await apiAddManufacture(payload); showPopup('Manufacture order created!'); }
      setForm(empty); setEditing(null); await reload();
    } catch (e) { showPopup(e.message, 'error'); }
  };

  return (
    <div>
      <div className="section-card">
        <h3 className="section-title">{editing ? '✏️ Edit Order' : '➕ New Manufacture Order'}</h3>
        <div className="form-grid">
          <input className="form-input-sm" placeholder="Order ID (e.g. MFG-002)"     value={form.orderId}   onChange={e => setForm({ ...form, orderId: e.target.value })} />
          <input className="form-input-sm" placeholder="Product Name"                value={form.product}   onChange={e => setForm({ ...form, product: e.target.value })} />
          <input className="form-input-sm" placeholder="Quantity" type="number"      value={form.quantity}  onChange={e => setForm({ ...form, quantity: e.target.value })} />
          <select className="form-select" value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}>
            <option>Planned</option><option>In Progress</option><option>Completed</option><option>On Hold</option>
          </select>
          <input className="form-input-sm" placeholder="Materials (comma-separated)" value={form.materials} onChange={e => setForm({ ...form, materials: e.target.value })} />
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <button className="btn btn-primary" onClick={save}>{editing ? '💾 Update' : '🏭 Create Order'}</button>
          {editing && <button className="btn btn-secondary" onClick={() => { setForm(empty); setEditing(null); }}>Cancel</button>}
        </div>
      </div>
      <div className="section-card" style={{ marginTop: 16 }}>
        <h3 className="section-title">🏭 All Manufacture Orders</h3>
        <table className="data-table">
          <thead><tr><th>Order ID</th><th>Product</th><th>Qty</th><th>Status</th><th>Materials</th><th>Start</th><th>Actions</th></tr></thead>
          <tbody>
            {(store.manufacture || []).map(m => (
              <tr key={m.id}>
                <td><span className="badge badge-blue">{m.orderId}</span></td>
                <td>{m.product}</td><td>{m.quantity}</td>
                <td><span className={`badge ${m.status === 'Completed' ? 'badge-green' : m.status === 'In Progress' ? 'badge-yellow' : m.status === 'On Hold' ? 'badge-red' : 'badge-blue'}`}>{m.status}</span></td>
                <td style={{ fontSize: 12 }}>{Array.isArray(m.materials) ? m.materials.join(', ') : m.materials}</td>
                <td style={{ fontSize: 12 }}>{formatTime(m.startDate)}</td>
                <td>
                  <button className="icon-btn" onClick={() => { setForm({ orderId: m.orderId, product: m.product, quantity: m.quantity, status: m.status, materials: Array.isArray(m.materials) ? m.materials.join(', ') : m.materials }); setEditing(m.id); }}>✏️</button>
                  <button className="icon-btn" onClick={async () => { await apiDeleteManufacture(m.id); await reload(); showPopup('Order removed'); }}>🗑️</button>
                </td>
              </tr>
            ))}
            {!store.manufacture?.length && <tr><td colSpan={7} className="empty-cell">No orders</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── CHAT (Admin) ──────────────────────────────────────────────────────────────
function AdminChat({ store, reload, user }) {
  const [reply, setReply]           = useState('');
  const [selectedUser, setSelectedUser] = useState(null);
  const endRef = useRef();

  const chatMessages = store.chatMessages || [];
  const users = [...new Set(chatMessages.map(m => m.from !== 'Admin' ? m.from : m.to).filter(Boolean))];

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [chatMessages]);

  const markRead = async (uname) => {
    setSelectedUser(uname);
    try { await apiMarkAdminRead(uname); await reload(); } catch {}
  };

  const send = async () => {
    if (!reply.trim() || !selectedUser) return;
    try {
      await apiSendChat('Admin', selectedUser, reply.trim());
      setReply(''); await reload();
    } catch {}
  };

  const thread = selectedUser
    ? chatMessages.filter(m => (m.from === selectedUser && m.to === 'Admin') || (m.from === 'Admin' && m.to === selectedUser))
    : [];

  return (
    <div style={{ display: 'flex', gap: 16, height: 'calc(100vh - 180px)' }}>
      <div className="section-card" style={{ width: 220, flexShrink: 0, overflowY: 'auto' }}>
        <h3 className="section-title">Users</h3>
        {users.length === 0 && <div style={{ color: '#aaa', fontSize: 13, textAlign: 'center', marginTop: 16 }}>No messages yet</div>}
        {users.map(u => {
          const unread = chatMessages.filter(m => m.from === u && !m.readByAdmin).length;
          return (
            <div key={u} onClick={() => markRead(u)} className={`chat-user-item ${selectedUser === u ? 'chat-user-active' : ''}`}>
              <div className="portal-avatar" style={{ background: '#3b82f6', width: 32, height: 32, fontSize: 13, flexShrink: 0 }}>{u[0]}</div>
              <span style={{ flex: 1, fontSize: 13 }}>{u}</span>
              {unread > 0 && <span className="portal-badge">{unread}</span>}
            </div>
          );
        })}
      </div>
      <div className="section-card" style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        {!selectedUser ? (
          <div className="empty-state">Select a user to view the chat</div>
        ) : (
          <>
            <h3 className="section-title" style={{ borderBottom: '1px solid #e5e7eb', paddingBottom: 12 }}>💬 Chat with {selectedUser}</h3>
            <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {thread.map(m => (
                <div key={m.id} style={{ display: 'flex', justifyContent: m.from === 'Admin' ? 'flex-end' : 'flex-start' }}>
                  <div style={{ maxWidth: '70%', background: m.from === 'Admin' ? '#3b82f6' : '#f3f4f6', color: m.from === 'Admin' ? '#fff' : '#1f2937', borderRadius: 12, padding: '8px 14px', fontSize: 14 }}>
                    <div>{m.message}</div>
                    <div style={{ fontSize: 10, opacity: 0.7, marginTop: 4 }}>{formatTime(m.time)}</div>
                  </div>
                </div>
              ))}
              {thread.length === 0 && <div style={{ textAlign: 'center', color: '#aaa', marginTop: 24 }}>Start the conversation</div>}
              <div ref={endRef} />
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
              <input className="form-input-sm" style={{ flex: 1 }} placeholder="Type a reply…" value={reply} onChange={e => setReply(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} />
              <button className="btn btn-primary" onClick={send}>Send</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
