import React, { useState } from 'react';
import LoginPage from './LoginPage';
import AdminPortal from './AdminPortal';
import UserPortal from './UserPortal';

export default function App() {
  const [loggedIn, setLoggedIn]       = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  const handleSignOut = () => {
    setLoggedIn(false);
    setCurrentUser(null);
  };

  if (!loggedIn) {
    return (
      <LoginPage
        onLogin={(user) => { setLoggedIn(true); setCurrentUser(user); }}
      />
    );
  }

  if (currentUser?.role === 'admin') {
    return <AdminPortal user={currentUser} onSignOut={handleSignOut} />;
  }

  return <UserPortal user={currentUser} onSignOut={handleSignOut} />;
}
