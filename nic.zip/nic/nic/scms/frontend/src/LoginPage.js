import React, { useState, useEffect, useRef } from 'react';
import './LoginPage.css';
import { getStore, saveStore } from './store';

function generateCaptchaText() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = '';
  for (let i = 0; i < 6; i++) result += chars.charAt(Math.floor(Math.random() * chars.length));
  return result;
}

const CaptchaCanvas = ({ text }) => {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    ctx.fillStyle = '#1a237e';
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 80; i++) {
      ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.4})`;
      ctx.fillRect(Math.random() * w, Math.random() * h, 2, 2);
    }
    for (let i = 0; i < 4; i++) {
      ctx.strokeStyle = `rgba(255,255,255,${Math.random() * 0.3 + 0.1})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(Math.random() * w, Math.random() * h);
      ctx.lineTo(Math.random() * w, Math.random() * h);
      ctx.stroke();
    }
    ctx.font = 'bold 28px Arial';
    ctx.textBaseline = 'middle';
    const ls = (w - 20) / text.length;
    for (let i = 0; i < text.length; i++) {
      const colors = ['#ffffff', '#ffeb3b', '#80cbc4', '#ef9a9a'];
      ctx.fillStyle = colors[i % colors.length];
      ctx.save();
      ctx.translate(10 + i * ls + ls / 2, h / 2);
      ctx.rotate((Math.random() - 0.5) * 0.4);
      ctx.fillText(text[i], -8, 0);
      ctx.restore();
    }
  }, [text]);
  return <canvas ref={canvasRef} width={160} height={48} style={{ display: 'block' }} />;
};

const GearIcon = ({ size, color, style }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={style}>
    <path fill={color} d="M43.3 7.5l-2.5 9.4c-2.6 0.8-5 2-7.2 3.5l-9-3.9-9.2 9.2 3.9 9c-1.5 2.2-2.7 4.6-3.5 7.2l-9.4 2.5v13l9.4 2.5c0.8 2.6 2 5 3.5 7.2l-3.9 9 9.2 9.2 9-3.9c2.2 1.5 4.6 2.7 7.2 3.5l2.5 9.4h13l2.5-9.4c2.6-0.8 5-2 7.2-3.5l9 3.9 9.2-9.2-3.9-9c1.5-2.2 2.7-4.6 3.5-7.2l9.4-2.5v-13l-9.4-2.5c-0.8-2.6-2-5-3.5-7.2l3.9-9-9.2-9.2-9 3.9c-2.2-1.5-4.6-2.7-7.2-3.5l-2.5-9.4h-13zm6.5 26c9.1 0 16.5 7.4 16.5 16.5S58.9 66.5 49.8 66.5 33.3 59.1 33.3 50s7.4-16.5 16.5-16.5z" />
  </svg>
);

// Admin credentials (fixed)
const ADMIN_CREDS = { username: 'TRP_RDD_2301', password: 'Scms@2301' };

export default function LoginPage({ onLogin }) {
  const [portalType, setPortalType] = useState('user'); // 'user' | 'admin'
  const [view, setView] = useState('signin'); // 'signin' | 'signup'

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [captchaInput, setCaptchaInput] = useState('');
  const [captchaText, setCaptchaText] = useState(generateCaptchaText());
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  // Signup form state
  const [suName, setSuName] = useState('');
  const [suUsername, setSuUsername] = useState('');
  const [suPassword, setSuPassword] = useState('');
  const [suConfirm, setSuConfirm] = useState('');
  const [suDept, setSuDept] = useState('');

  const refreshCaptcha = () => { setCaptchaText(generateCaptchaText()); setCaptchaInput(''); };

  const switchPortal = (type) => {
    setPortalType(type);
    setView('signin');
    setUsername(type === 'admin' ? ADMIN_CREDS.username : '');
    setPassword('');
    setError(''); setInfo('');
    refreshCaptcha();
  };

  const handleSignIn = (e) => {
    e.preventDefault();
    setError('');
    if (captchaInput.toUpperCase() !== captchaText) {
      setError('Captcha does not match. Please try again.');
      refreshCaptcha();
      return;
    }
    if (portalType === 'admin') {
      if (username !== ADMIN_CREDS.username || password !== ADMIN_CREDS.password) {
        setError('Invalid admin credentials.');
        refreshCaptcha();
        return;
      }
      onLogin({ username, name: 'Admin', role: 'admin' });
      return;
    }

    // ── User portal sign-in ──
    const store = getStore();

    // 1) Check self-registered (signed-up) users first
    const signedUp = (store.signedUpUsers || []).find(u => u.username === username);
    if (signedUp) {
      if (signedUp.password !== password) {
        setError('Incorrect password for this account.');
        refreshCaptcha();
        return;
      }
      onLogin({ username: signedUp.username, name: signedUp.name, role: 'user', department: signedUp.department || 'Employee', isSignedUp: true });
      return;
    }

    // 2) Fall back to admin-provisioned employees (Employee ID + default password)
    const emp = (store.employees || []).find(e => e.empId === username && e.status === 'Active');
    if (emp) {
      if (password !== 'user123') {
        setError('Invalid password. Default for admin-added employees: user123');
        refreshCaptcha();
        return;
      }
      onLogin({ username: emp.empId, name: emp.name, role: 'user', empId: emp.empId, department: emp.department });
      return;
    }

    setError('Account not found. New users should Sign Up first.');
    refreshCaptcha();
  };

  const handleSignUp = (e) => {
    e.preventDefault();
    setError(''); setInfo('');
    if (!suName.trim() || !suUsername.trim() || !suPassword || !suConfirm) {
      setError('Please fill in all required fields.');
      return;
    }
    if (suPassword.length < 4) {
      setError('Password must be at least 4 characters.');
      return;
    }
    if (suPassword !== suConfirm) {
      setError('Passwords do not match.');
      return;
    }
    if (captchaInput.toUpperCase() !== captchaText) {
      setError('Captcha does not match. Please try again.');
      refreshCaptcha();
      return;
    }

    const store = getStore();
    const usernameTaken =
      (store.signedUpUsers || []).some(u => u.username.toLowerCase() === suUsername.trim().toLowerCase()) ||
      (store.employees || []).some(e => e.empId.toLowerCase() === suUsername.trim().toLowerCase()) ||
      suUsername.trim().toLowerCase() === ADMIN_CREDS.username.toLowerCase();

    if (usernameTaken) {
      setError('This username is already taken. Please choose another.');
      refreshCaptcha();
      return;
    }

    const newUser = {
      username: suUsername.trim(),
      password: suPassword,
      name: suName.trim(),
      department: suDept.trim() || 'Employee',
      createdAt: new Date().toISOString(),
    };
    const updatedUsers = [...(store.signedUpUsers || []), newUser];
    saveStore({ ...store, signedUpUsers: updatedUsers });

    // Reset signup form, switch to sign-in with username pre-filled
    setSuName(''); setSuUsername(''); setSuPassword(''); setSuConfirm(''); setSuDept('');
    setUsername(newUser.username);
    setPassword('');
    setView('signin');
    setInfo('✅ Account created! Please sign in with your new username and password.');
    refreshCaptcha();
  };

  const isAdmin = portalType === 'admin';
  const btnColor = isAdmin ? '#3b82f6' : '#22c55e';

  return (
    <div className="page-wrapper">
      <div className="card">
        <div className="left-panel">
          <div className="logo-area" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
            <div className="logo-icon">
              <svg width="64" height="64" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
                <rect x="4" y="26" width="36" height="22" rx="3" fill="#f57f17" />
                <rect x="4" y="26" width="20" height="22" rx="2" fill="#ff9800" />
                <rect x="36" y="30" width="18" height="18" rx="2" fill="#f57f17" />
                <rect x="38" y="32" width="10" height="8" rx="1" fill="#90caf9" />
                <circle cx="14" cy="50" r="5" fill="#37474f" /><circle cx="14" cy="50" r="2.5" fill="#78909c" />
                <circle cx="44" cy="50" r="5" fill="#37474f" /><circle cx="44" cy="50" r="2.5" fill="#78909c" />
              </svg>
            </div>
          </div>

          {/* Portal selector */}
          <div className="portal-select-row">
            <span className="portal-select-label">SCMS</span>
            <select className="portal-select" value={portalType} onChange={e => switchPortal(e.target.value)}>
              <option value="user">👤 User Portal</option>
              <option value="admin">🛡️ Admin Portal</option>
            </select>
          </div>

          <h1 className="sign-in-title">{view === 'signup' ? 'Create Account' : 'Sign in'}</h1>
          <p className="sign-in-sub">
            {isAdmin ? '🛡️ Admin Portal — ' : '👤 User Portal — '}
            <span className="scms-brand">SCMS</span>
          </p>

          {!isAdmin && view === 'signin' && (
            <div className="new-user-banner" style={{ background: '#e8f5e9', borderColor: '#388e3c', color: '#1b5e20' }}>
              👷 New here? <strong onClick={() => { setView('signup'); setError(''); setInfo(''); }} style={{ cursor: 'pointer', textDecoration: 'underline' }}>Sign up</strong> to create your own username & password. Already added by Admin? Use your <strong>Employee ID</strong> + <strong>user123</strong>.
            </div>
          )}

          {info && <p className="info-msg">{info}</p>}

          {/* ── SIGN IN FORM ── */}
          {view === 'signin' && (
            <form className="login-form" onSubmit={handleSignIn}>
              <input type="text" className="form-input" placeholder={isAdmin ? 'Admin Username' : 'Username or Employee ID'}
                value={username} onChange={e => setUsername(e.target.value)} />
              <input type="password" className="form-input" placeholder="Password"
                value={password} onChange={e => setPassword(e.target.value)} />
              <div className="captcha-row">
                <div className="captcha-box" onClick={refreshCaptcha} title="Click to refresh" style={{ cursor: 'pointer' }}>
                  <CaptchaCanvas text={captchaText} />
                </div>
                <input type="text" className="captcha-input" placeholder="Enter Captcha"
                  value={captchaInput} onChange={e => setCaptchaInput(e.target.value)} />
              </div>
              <p className="captcha-hint">Can't read? Click image to refresh.</p>
              {error && <p className="error-msg">{error}</p>}
              <button type="submit" className="sign-in-btn" style={{ background: btnColor }}>Sign in</button>
              {!isAdmin && (
                <button type="button" className="know-more-btn" style={{ marginTop: 4, width: '100%' }}
                  onClick={() => { setView('signup'); setError(''); setInfo(''); }}>
                  ✍️ New user? Sign up here
                </button>
              )}
            </form>
          )}

          {/* ── SIGN UP FORM (User Portal only) ── */}
          {view === 'signup' && !isAdmin && (
            <form className="login-form" onSubmit={handleSignUp}>
              <input type="text" className="form-input" placeholder="Full Name"
                value={suName} onChange={e => setSuName(e.target.value)} />
              <input type="text" className="form-input" placeholder="Choose a Username"
                value={suUsername} onChange={e => setSuUsername(e.target.value)} />
              <input type="text" className="form-input" placeholder="Department (optional)"
                value={suDept} onChange={e => setSuDept(e.target.value)} />
              <input type="password" className="form-input" placeholder="Choose a Password"
                value={suPassword} onChange={e => setSuPassword(e.target.value)} />
              <input type="password" className="form-input" placeholder="Confirm Password"
                value={suConfirm} onChange={e => setSuConfirm(e.target.value)} />
              <div className="captcha-row">
                <div className="captcha-box" onClick={refreshCaptcha} title="Click to refresh" style={{ cursor: 'pointer' }}>
                  <CaptchaCanvas text={captchaText} />
                </div>
                <input type="text" className="captcha-input" placeholder="Enter Captcha"
                  value={captchaInput} onChange={e => setCaptchaInput(e.target.value)} />
              </div>
              <p className="captcha-hint">Can't read? Click image to refresh.</p>
              {error && <p className="error-msg">{error}</p>}
              <button type="submit" className="sign-in-btn" style={{ background: btnColor }}>Create Account</button>
              <button type="button" className="know-more-btn" style={{ marginTop: 4, width: '100%' }}
                onClick={() => { setView('signin'); setError(''); setInfo(''); }}>
                ← Already have an account? Sign in
              </button>
            </form>
          )}
        </div>
        <div className="divider" />
        <div className="right-panel">
          <div className="gears-container">
            <div className="gear gear-center"><GearIcon size={130} color="#d4956a" /></div>
            <div className="gear gear-top-left"><GearIcon size={70} color="#4db6ac" /></div>
            <div className="gear gear-top-right"><GearIcon size={60} color="#4db6ac" /></div>
            <div className="gear gear-bottom-right"><GearIcon size={75} color="#4db6ac" /></div>
          </div>
          <h2 className="config-title">{isAdmin ? 'Admin Access' : (view === 'signup' ? 'New User Registration' : 'User Access')}</h2>
          <p className="config-desc">
            {isAdmin
              ? 'Manage stores, employees, materials, inventory, suppliers & notifications.'
              : view === 'signup'
                ? 'Create your own account. Multiple users can sign up — each with their own unique username and password.'
                : 'View notifications, purchase materials, bookmark messages & chat with admin.'}
          </p>
        </div>
      </div>
    </div>
  );
}
