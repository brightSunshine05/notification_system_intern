import React, { useState, useEffect, useRef, useCallback } from 'react';
import { getStore, saveStore, formatTime, timeAgo } from './store';
import './Portal.css';

const SIDEBAR_ITEMS = [
  { key: 'dashboard', icon: '🏠', label: 'Dashboard' },
  { key: 'notifications', icon: '🔔', label: 'Notifications' },
  { key: 'bookmarks', icon: '🔖', label: 'Bookmarks' },
  { key: 'materials', icon: '🧱', label: 'Materials' },
  { key: 'myrequests', icon: '📋', label: 'My Requests' },
  { key: 'chat', icon: '💬', label: 'Chat with Admin' },
];

export default function UserPortal({ user, onSignOut }) {
  const [section, setSection] = useState('dashboard');
  const [store, setStore] = useState(getStore());
  const [popup, setPopup] = useState(null);
  const [bellOpen, setBellOpen] = useState(false);
  const [seenNotifIds, setSeenNotifIds] = useState(() => {
    try { return JSON.parse(localStorage.getItem(`scms_seen_${user?.username}`) || '[]'); } catch { return []; }
  });
  const lastNotifCount = useRef(null);
  const lastMaterialIds = useRef(null);
  const lastChatCount = useRef(null);

  // Poll store for changes (admin updates) every 2s
  useEffect(() => {
    const iv = setInterval(() => {
      const fresh = getStore();
      setStore(fresh);
    }, 2000);
    return () => clearInterval(iv);
  }, []);

  const update = (patch) => {
    const s = { ...getStore(), ...patch };
    saveStore(s);
    setStore(s);
  };

  const showPopup = useCallback((message, type = 'success') => {
    setPopup({ message, type });
    setTimeout(() => setPopup(null), 3000);
  }, []);

  // Detect new notifications from admin and pop them up
  useEffect(() => {
    const notifs = store.notifications || [];
    if (lastNotifCount.current === null) {
      lastNotifCount.current = notifs.length;
      return;
    }
    if (notifs.length > lastNotifCount.current) {
      const newest = notifs[0];
      showPopup(`🔔 New: ${newest.title}`, 'info');
    }
    lastNotifCount.current = notifs.length;
  }, [store.notifications, showPopup]);

  // Detect new materials added by admin -> popup
  useEffect(() => {
    const mats = store.materials || [];
    const ids = mats.map(m => m.id);
    if (lastMaterialIds.current === null) {
      lastMaterialIds.current = ids;
      return;
    }
    const newOnes = ids.filter(id => !lastMaterialIds.current.includes(id));
    if (newOnes.length > 0) {
      const newMat = mats.find(m => m.id === newOnes[0]);
      showPopup(`🧱 New material available: ${newMat.name}!`, 'success');
    }
    lastMaterialIds.current = ids;
  }, [store.materials, showPopup]);

  // Detect new chat reply from admin
  useEffect(() => {
    const fromAdminToMe = (store.chatMessages || []).filter(m => m.from === 'Admin' && m.to === user?.username);
    if (lastChatCount.current === null) {
      lastChatCount.current = fromAdminToMe.length;
      return;
    }
    if (fromAdminToMe.length > lastChatCount.current) {
      showPopup('💬 New reply from Admin', 'info');
    }
    lastChatCount.current = fromAdminToMe.length;
  }, [store.chatMessages, user, showPopup]);

  const markNotifSeen = (id) => {
    const updated = [...new Set([...seenNotifIds, id])];
    setSeenNotifIds(updated);
    localStorage.setItem(`scms_seen_${user?.username}`, JSON.stringify(updated));
  };

  const myNotifs = store.notifications || [];
  const unreadNotif = myNotifs.filter(n => !seenNotifIds.includes(n.id)).length;
  const unreadChat = (store.chatMessages || []).filter(m => m.from === 'Admin' && m.to === user?.username && !m.readByUser).length;
  const bookmarked = myNotifs.filter(n => (n.bookmarkedBy || []).includes(user?.username));

  return (
    <div className="portal-shell">
      {popup && (
        <div className={`popup-toast popup-${popup.type}`}>
          {popup.type === 'success' ? '✅' : popup.type === 'error' ? '❌' : 'ℹ️'} {popup.message}
        </div>
      )}

      <aside className="portal-sidebar sidebar-user">
        <div className="portal-logo">
          <svg width="32" height="32" viewBox="0 0 64 64">
            <rect x="4" y="26" width="36" height="22" rx="3" fill="#f57f17" />
            <rect x="4" y="26" width="20" height="22" rx="2" fill="#ff9800" />
            <rect x="36" y="30" width="18" height="18" rx="2" fill="#f57f17" />
            <rect x="38" y="32" width="10" height="8" rx="1" fill="#90caf9" />
            <circle cx="14" cy="50" r="5" fill="#37474f" /><circle cx="14" cy="50" r="2.5" fill="#78909c" />
            <circle cx="44" cy="50" r="5" fill="#37474f" /><circle cx="44" cy="50" r="2.5" fill="#78909c" />
          </svg>
          <span className="portal-logo-text">SCMS</span>
          <span style={{ fontSize: 10, background: '#22c55e', color: '#fff', borderRadius: 4, padding: '1px 6px', marginLeft: 4 }}>USER</span>
        </div>
        <nav className="portal-nav">
          {SIDEBAR_ITEMS.map(item => (
            <div key={item.key} className={`portal-nav-item ${section === item.key ? 'portal-nav-active' : ''}`} onClick={() => setSection(item.key)}>
              <span className="portal-nav-icon">{item.icon}</span>
              <span>{item.label}</span>
              {item.key === 'notifications' && unreadNotif > 0 && <span className="portal-badge">{unreadNotif}</span>}
              {item.key === 'chat' && unreadChat > 0 && <span className="portal-badge" style={{ background: '#f59e0b' }}>{unreadChat}</span>}
              {item.key === 'bookmarks' && bookmarked.length > 0 && <span className="portal-badge" style={{ background: '#8b5cf6' }}>{bookmarked.length}</span>}
            </div>
          ))}
        </nav>
        <div className="portal-sidebar-footer">
          <div className="portal-user-chip">
            <div className="portal-avatar" style={{ background: '#22c55e' }}>{user?.name ? user.name[0] : 'U'}</div>
            <div className="portal-user-info">
              <span className="portal-user-name">{user?.name || user?.username}</span>
              <span className="portal-user-role">{user?.department || 'Employee'}</span>
            </div>
          </div>
          <button className="portal-signout" onClick={onSignOut}>Sign Out</button>
        </div>
      </aside>

      <main className="portal-main">
        <header className="portal-header">
          <div>
            <h1 className="portal-page-title">{SIDEBAR_ITEMS.find(i => i.key === section)?.label || 'Dashboard'}</h1>
            <p className="portal-page-sub">Welcome, <strong>{user?.name}</strong> — {new Date().toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
          </div>
          <div style={{ position: 'relative' }}>
            <button className="bell-btn" onClick={() => setBellOpen(o => !o)}>
              🔔
              {(unreadNotif + unreadChat) > 0 && <span className="bell-count">{unreadNotif + unreadChat}</span>}
            </button>
            {bellOpen && (
              <div className="bell-dropdown">
                <div className="bell-header">Notification Center</div>
                {myNotifs.filter(n => !seenNotifIds.includes(n.id)).slice(0, 6).map(n => (
                  <div key={n.id} className="bell-item" onClick={() => { markNotifSeen(n.id); setSection('notifications'); setBellOpen(false); }}>
                    🔔 <strong>{n.title}</strong>
                    <div style={{ fontSize: 11, color: '#666' }}>{n.message.slice(0, 60)}…</div>
                    <div style={{ fontSize: 10, color: '#999', marginTop: 2 }}>{formatTime(n.time)}</div>
                  </div>
                ))}
                {(store.chatMessages || []).filter(m => m.from === 'Admin' && m.to === user?.username && !m.readByUser).slice(0, 4).map(m => (
                  <div key={m.id} className="bell-item bell-chat" onClick={() => setSection('chat')}>
                    💬 <strong>Admin</strong>: {m.message.slice(0, 50)}…
                    <div style={{ fontSize: 10, color: '#999', marginTop: 2 }}>{formatTime(m.time)}</div>
                  </div>
                ))}
                {(unreadNotif + unreadChat) === 0 && <div style={{ padding: 16, color: '#888', textAlign: 'center' }}>All caught up!</div>}
              </div>
            )}
          </div>
        </header>

        <div className="portal-content">
          {section === 'dashboard' && <UserDashboard store={store} user={user} setSection={setSection} />}
          {section === 'notifications' && <UserNotifications store={store} update={update} user={user} showPopup={showPopup} seenNotifIds={seenNotifIds} markNotifSeen={markNotifSeen} />}
          {section === 'bookmarks' && <UserBookmarks store={store} update={update} user={user} />}
          {section === 'materials' && <UserMaterials store={store} update={update} user={user} showPopup={showPopup} />}
          {section === 'myrequests' && <UserRequests store={store} user={user} />}
          {section === 'chat' && <UserChat store={store} update={update} user={user} />}
        </div>
      </main>
    </div>
  );
}

// ── DASHBOARD ────────────────────────────────────────────────────────────────
function UserDashboard({ store, user, setSection }) {
  const myReqs = (store.purchaseRequests || []).filter(r => r.userId === user?.username);
  const stats = [
    { label: 'Notifications', value: store.notifications?.length || 0, icon: '🔔', color: '#3b82f6', key: 'notifications' },
    { label: 'Available Materials', value: store.materials?.length || 0, icon: '🧱', color: '#8b5cf6', key: 'materials' },
    { label: 'My Requests', value: myReqs.length, icon: '📋', color: '#f59e0b', key: 'myrequests' },
    { label: 'Pending Approval', value: myReqs.filter(r => r.status === 'Pending').length, icon: '⏳', color: '#ef4444', key: 'myrequests' },
  ];
  return (
    <div>
      <div className="stat-grid">
        {stats.map(s => (
          <div key={s.label} className="stat-card" style={{ borderTop: `4px solid ${s.color}`, cursor: 'pointer' }} onClick={() => setSection(s.key)}>
            <span style={{ fontSize: 28 }}>{s.icon}</span>
            <span className="stat-value" style={{ color: s.color }}>{s.value}</span>
            <span className="stat-label">{s.label}</span>
          </div>
        ))}
      </div>
      <div className="section-card" style={{ marginTop: 24 }}>
        <h3 className="section-title">🧱 Recently Added Materials</h3>
        <table className="data-table">
          <thead><tr><th>Name</th><th>Category</th><th>Available Qty</th><th>Price</th><th>Added</th></tr></thead>
          <tbody>
            {(store.materials || []).slice(-5).reverse().map(m => (
              <tr key={m.id}>
                <td><strong>{m.name}</strong></td><td>{m.category}</td><td>{m.quantity} {m.unit}</td><td>₹{m.price}</td>
                <td style={{ fontSize: 12 }}>{formatTime(m.addedAt)}</td>
              </tr>
            ))}
            {!store.materials?.length && <tr><td colSpan={5} className="empty-cell">No materials yet</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── NOTIFICATIONS ────────────────────────────────────────────────────────────
function UserNotifications({ store, update, user, showPopup, seenNotifIds, markNotifSeen }) {
  const [replyText, setReplyText] = useState({});
  const [filter, setFilter] = useState('all');

  const notifs = store.notifications || [];

  const toggleBookmark = (id) => {
    const updated = notifs.map(n => {
      if (n.id !== id) return n;
      const bm = n.bookmarkedBy || [];
      const has = bm.includes(user.username);
      return { ...n, bookmarkedBy: has ? bm.filter(u => u !== user.username) : [...bm, user.username] };
    });
    update({ notifications: updated });
  };

  const sendReply = (id) => {
    const text = (replyText[id] || '').trim();
    if (!text) return;
    const updated = notifs.map(n => n.id === id ? { ...n, replies: [...(n.replies || []), { from: user.name || user.username, message: text, time: new Date().toISOString() }] } : n);
    update({ notifications: updated });
    setReplyText({ ...replyText, [id]: '' });
    showPopup('Reply sent to Admin!');
  };

  const filtered = notifs.filter(n => {
    if (filter === 'unread') return !seenNotifIds.includes(n.id);
    if (filter === 'bookmarked') return (n.bookmarkedBy || []).includes(user.username);
    if (filter !== 'all') return n.type === filter;
    return true;
  });

  return (
    <div>
      <div className="section-card">
        <div className="nd-toolbar" style={{ marginBottom: 0 }}>
          <div className="nd-filters">
            {['all', 'unread', 'bookmarked', 'alert', 'info', 'success'].map(f => (
              <button key={f} className={`nd-filter-btn ${filter === f ? 'nd-filter-active' : ''}`} onClick={() => setFilter(f)}>
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="section-card" style={{ marginTop: 16 }}>
        {filtered.map(n => {
          const isSeen = seenNotifIds.includes(n.id);
          const isBookmarked = (n.bookmarkedBy || []).includes(user.username);
          return (
            <div key={n.id} className={`notif-item notif-${n.type} ${!isSeen ? 'notif-unread' : ''}`} onClick={() => !isSeen && markNotifSeen(n.id)}>
              <div className="notif-top">
                <span className="notif-title">{n.title}</span>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span className={`badge badge-${n.type === 'info' ? 'blue' : n.type === 'alert' ? 'red' : 'green'}`}>{n.type}</span>
                  <span style={{ fontSize: 11, color: '#888' }}>{formatTime(n.time)}</span>
                  <button className="icon-btn" title="Bookmark" onClick={(e) => { e.stopPropagation(); toggleBookmark(n.id); }}>
                    {isBookmarked ? '🔖' : '📑'}
                  </button>
                  {!isSeen && <span className="badge badge-red">New</span>}
                </div>
              </div>
              <p style={{ fontSize: 14, color: '#4b5563', margin: '4px 0 8px' }}>{n.message}</p>
              <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 8 }}>
                {isSeen ? '✓✓ Seen' : '✓ Sent'} · Last updated: {formatTime(n.time)}
              </div>

              {n.replies?.length > 0 && (
                <div style={{ background: '#f9fafb', borderRadius: 8, padding: 10, marginBottom: 8 }}>
                  {n.replies.map((r, i) => (
                    <div key={i} style={{ fontSize: 13, marginTop: 4 }}>
                      <strong>{r.from}:</strong> {r.message} <span style={{ color: '#9ca3af', fontSize: 11 }}>— {formatTime(r.time)}</span>
                    </div>
                  ))}
                </div>
              )}

              <div style={{ display: 'flex', gap: 8 }} onClick={e => e.stopPropagation()}>
                <input className="form-input-sm" style={{ flex: 1 }} placeholder="Reply to this notification…"
                  value={replyText[n.id] || ''} onChange={e => setReplyText({ ...replyText, [n.id]: e.target.value })}
                  onKeyDown={e => e.key === 'Enter' && sendReply(n.id)} />
                <button className="btn btn-sm btn-primary" onClick={() => sendReply(n.id)}>Reply</button>
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && <div className="empty-state">No notifications match this filter</div>}
      </div>
    </div>
  );
}

// ── BOOKMARKS ────────────────────────────────────────────────────────────────
function UserBookmarks({ store, update, user }) {
  const notifs = store.notifications || [];
  const bookmarked = notifs.filter(n => (n.bookmarkedBy || []).includes(user.username));

  const toggleBookmark = (id) => {
    const updated = notifs.map(n => {
      if (n.id !== id) return n;
      const bm = n.bookmarkedBy || [];
      return { ...n, bookmarkedBy: bm.filter(u => u !== user.username) };
    });
    update({ notifications: updated });
  };

  return (
    <div className="section-card">
      <h3 className="section-title">🔖 Bookmarked Notifications ({bookmarked.length})</h3>
      {bookmarked.map(n => (
        <div key={n.id} className={`notif-item notif-${n.type}`}>
          <div className="notif-top">
            <span className="notif-title">{n.title}</span>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span style={{ fontSize: 11, color: '#888' }}>{formatTime(n.time)}</span>
              <button className="icon-btn" onClick={() => toggleBookmark(n.id)} title="Remove bookmark">🔖</button>
            </div>
          </div>
          <p style={{ fontSize: 14, color: '#4b5563', margin: '4px 0' }}>{n.message}</p>
        </div>
      ))}
      {bookmarked.length === 0 && <div className="empty-state">No bookmarked notifications. Tap 📑 on any notification to save it here.</div>}
    </div>
  );
}

// ── MATERIALS (purchase) ──────────────────────────────────────────────────────
function UserMaterials({ store, update, user, showPopup }) {
  const [qtyMap, setQtyMap] = useState({});

  const buy = (mat) => {
    const qty = +(qtyMap[mat.id] || 1);
    if (qty <= 0 || qty > mat.quantity) { showPopup('Invalid quantity', 'error'); return; }
    const reqs = store.purchaseRequests || [];
    const req = { id: Date.now(), userId: user.username, userName: user.name, materialId: mat.id, materialName: mat.name, quantity: qty, status: 'Pending', time: new Date().toISOString() };
    update({ purchaseRequests: [...reqs, req] });
    setQtyMap({ ...qtyMap, [mat.id]: '' });
    showPopup(`Purchase request for ${qty} ${mat.name} sent to Admin!`);
  };

  return (
    <div className="section-card">
      <h3 className="section-title">🧱 Available Materials ({store.materials?.length || 0})</h3>
      <div className="material-grid">
        {(store.materials || []).map(m => (
          <div key={m.id} className="material-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <h4 style={{ fontSize: 16, fontWeight: 700, color: '#1f2937' }}>{m.name}</h4>
              <span className="badge badge-blue">{m.category}</span>
            </div>
            <p style={{ fontSize: 13, color: '#6b7280', margin: '6px 0' }}>{m.description}</p>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: '#374151', marginBottom: 8 }}>
              <span>Stock: <strong>{m.quantity} {m.unit}</strong></span>
              <span>₹{m.price} / {m.unit}</span>
            </div>
            <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 10 }}>
              Last updated: {formatTime(m.modifiedAt || m.addedAt)}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input type="number" className="form-input-sm" style={{ width: 70 }} placeholder="Qty" min={1} max={m.quantity}
                value={qtyMap[m.id] || ''} onChange={e => setQtyMap({ ...qtyMap, [m.id]: e.target.value })} />
              <button className="btn btn-primary btn-sm" style={{ flex: 1 }} disabled={m.quantity === 0} onClick={() => buy(m)}>
                {m.quantity === 0 ? 'Out of Stock' : '🛒 Request Purchase'}
              </button>
            </div>
          </div>
        ))}
      </div>
      {!store.materials?.length && <div className="empty-state">No materials available yet</div>}
    </div>
  );
}

// ── MY REQUESTS ──────────────────────────────────────────────────────────────
function UserRequests({ store, user }) {
  const myReqs = (store.purchaseRequests || []).filter(r => r.userId === user.username).reverse();
  return (
    <div className="section-card">
      <h3 className="section-title">📋 My Purchase Requests ({myReqs.length})</h3>
      <table className="data-table">
        <thead><tr><th>Material</th><th>Qty</th><th>Status</th><th>Requested</th><th>Resolved</th></tr></thead>
        <tbody>
          {myReqs.map(r => (
            <tr key={r.id}>
              <td><strong>{r.materialName}</strong></td><td>{r.quantity}</td>
              <td><span className={`badge ${r.status === 'Approved' ? 'badge-green' : r.status === 'Rejected' ? 'badge-red' : 'badge-yellow'}`}>{r.status}</span></td>
              <td style={{ fontSize: 12 }}>{formatTime(r.time)}</td>
              <td style={{ fontSize: 12 }}>{r.resolvedAt ? formatTime(r.resolvedAt) : '—'}</td>
            </tr>
          ))}
          {myReqs.length === 0 && <tr><td colSpan={5} className="empty-cell">No requests yet</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

// ── CHAT (User side) ─────────────────────────────────────────────────────────
function UserChat({ store, update, user }) {
  const [msg, setMsg] = useState('');
  const endRef = useRef();
  const chatMessages = store.chatMessages || [];
  const thread = chatMessages.filter(m => (m.from === user.username && m.to === 'Admin') || (m.from === 'Admin' && m.to === user.username));

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [chatMessages]);

  // Mark admin->user messages as read when viewing
  useEffect(() => {
    const hasUnread = chatMessages.some(m => m.from === 'Admin' && m.to === user.username && !m.readByUser);
    if (hasUnread) {
      update({ chatMessages: chatMessages.map(m => (m.from === 'Admin' && m.to === user.username) ? { ...m, readByUser: true } : m) });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const send = () => {
    if (!msg.trim()) return;
    const newMsg = { id: Date.now(), from: user.username, to: 'Admin', message: msg.trim(), time: new Date().toISOString(), readByAdmin: false };
    update({ chatMessages: [...chatMessages, newMsg] });
    setMsg('');
  };

  return (
    <div className="section-card" style={{ height: 'calc(100vh - 220px)', display: 'flex', flexDirection: 'column' }}>
      <h3 className="section-title" style={{ borderBottom: '1px solid #e5e7eb', paddingBottom: 12 }}>💬 Chat with Admin</h3>
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {thread.map(m => (
          <div key={m.id} style={{ display: 'flex', justifyContent: m.from === user.username ? 'flex-end' : 'flex-start' }}>
            <div style={{ maxWidth: '70%', background: m.from === user.username ? '#22c55e' : '#f3f4f6', color: m.from === user.username ? '#fff' : '#1f2937', borderRadius: 12, padding: '8px 14px', fontSize: 14 }}>
              <div>{m.message}</div>
              <div style={{ fontSize: 10, opacity: 0.7, marginTop: 4 }}>{formatTime(m.time)}</div>
            </div>
          </div>
        ))}
        {thread.length === 0 && <div style={{ textAlign: 'center', color: '#aaa', marginTop: 24 }}>Send a message to start chatting with Admin</div>}
        <div ref={endRef} />
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
        <input className="form-input-sm" style={{ flex: 1 }} placeholder="Type a message to Admin…" value={msg} onChange={e => setMsg(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} />
        <button className="btn btn-primary" onClick={send}>Send</button>
      </div>
    </div>
  );
}
