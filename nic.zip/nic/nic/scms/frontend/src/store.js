// ─────────────────────────────────────────────────────────────────────────────
// store.js  ―  API client wired to the FastAPI backend (http://localhost:8000)
//
// CONTRACT (must not break any component):
//   getStore()   → returns last-fetched state SYNCHRONOUSLY from cache,
//                  and fires an async refresh in the background
//   saveStore()  → diffs new state vs cache, fires the right API call(s)
//   formatTime() → unchanged
//   timeAgo()    → unchanged
//   getDefaultStore() → returns empty shell (legacy compat, never used)
//   apiSignIn / apiSignUp → used by LoginPage
//   api*  exports → used by AdminPortal
// ─────────────────────────────────────────────────────────────────────────────

const BASE = 'http://localhost:8000/api';

// ── internal cache ────────────────────────────────────────────────────────────
let _cache = _emptyStore();

function _emptyStore() {
  return {
    notifications: [],
    materials: [],
    employees: [],
    stores: [],
    suppliers: [],
    inventory: [],
    manufacture: [],
    chatMessages: [],
    purchaseRequests: [],
    signedUpUsers: [],
  };
}

// ── low-level fetch ───────────────────────────────────────────────────────────
async function _req(path, opts = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
    ...opts,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || `HTTP ${res.status}`);
  }
  return res.json();
}

// ── normalise raw API responses into the shape components expect ──────────────
function _normalise(raw) {
  return {
    notifications: (raw.notifications || []).map(n => ({
      id:           n.notification_id,
      type:         n.type         || 'info',
      title:        n.title        || 'Notification',
      message:      n.message,
      time:         n.created_on,
      read:         n.is_read,
      from:         'Admin',
      replies:      Array.isArray(n.replies) ? n.replies : [],
      bookmarkedBy: Array.isArray(n.bookmarked_by) ? n.bookmarked_by : [],
    })),
    materials: (raw.materials || []).map(m => ({
      id:          m.id,
      name:        m.name,
      category:    m.category    || '',
      quantity:    m.quantity,
      unit:        m.unit        || 'pcs',
      price:       parseFloat(m.price || 0),
      description: m.description || '',
      addedBy:     m.added_by    || 'Admin',
      addedAt:     m.added_at,
      modifiedAt:  m.modified_at,
    })),
    employees: (raw.employees || []).map(e => ({
      id:         e.id,
      empId:      e.emp_id,
      name:       e.name,
      department: e.department || '',
      email:      e.email      || '',
      phone:      e.phone      || '',
      status:     e.status,
      joinedAt:   e.joined_at,
    })),
    stores: (raw.stores || []).map(s => ({
      id:       s.id,
      storeId:  s.store_id,
      name:     s.name,
      location: s.location || '',
      manager:  s.manager  || '',
      capacity: s.capacity || 0,
      status:   s.status,
    })),
    suppliers: (raw.suppliers || []).map(s => ({
      id:         s.id,
      supplierId: s.supplier_id,
      name:       s.name,
      contact:    s.contact   || '',
      phone:      s.phone     || '',
      email:      s.email     || '',
      materials:  s.materials || '',
      status:     s.status,
    })),
    inventory: (raw.inventory || []).map(i => ({
      id:       i.id,
      itemCode: i.item_code,
      name:     i.name,
      category: i.category || '',
      quantity: i.quantity,
      minQty:   i.min_qty  || 0,
      unit:     i.unit     || 'pcs',
      location: i.location || '',
      supplier: i.supplier || '',
    })),
    manufacture: (raw.manufacture || []).map(m => ({
      id:        m.id,
      orderId:   m.order_id,
      product:   m.product,
      quantity:  m.quantity,
      status:    m.status,
      materials: Array.isArray(m.materials) ? m.materials : [],
      startDate: m.start_date,
      endDate:   m.end_date || null,
    })),
    chatMessages: (raw.chatMessages || []).map(c => ({
      id:          c.id,
      from:        c.from_user,
      to:          c.to_user,
      message:     c.message,
      readByAdmin: c.read_by_admin,
      readByUser:  c.read_by_user,
      time:        c.created_on,
    })),
    purchaseRequests: (raw.purchaseRequests || []).map(r => ({
      id:           r.id,
      userId:       r.user_id,
      userName:     r.user_name     || '',
      materialId:   r.material_id,
      materialName: r.material_name || '',
      quantity:     r.quantity,
      status:       r.status,
      resolvedAt:   r.resolved_at   || null,
      time:         r.created_on,
    })),
    signedUpUsers: [],
  };
}

// ── fetch ALL data from backend in parallel ───────────────────────────────────
async function _fetchAll() {
  const [notifications, materials, employees, stores, suppliers,
         inventory, manufacture, chatMessages, purchaseRequests] = await Promise.all([
    _req('/notifications/all').catch(() => []),
    _req('/materials/').catch(() => []),
    _req('/employees/').catch(() => []),
    _req('/stores/').catch(() => []),
    _req('/suppliers/').catch(() => []),
    _req('/inventory/').catch(() => []),
    _req('/manufacture/').catch(() => []),
    _req('/chat/').catch(() => []),
    _req('/purchases/').catch(() => []),
  ]);
  return { notifications, materials, employees, stores, suppliers,
           inventory, manufacture, chatMessages, purchaseRequests };
}

// ── PUBLIC: getStore() ────────────────────────────────────────────────────────
// Returns cache synchronously (so useState(getStore()) works in components).
// Fires async refresh so cache is up-to-date for the next poll cycle.
export function getStore() {
  // fire-and-forget background refresh
  _fetchAll().then(raw => { _cache = _normalise(raw); }).catch(() => {});
  return _cache;
}

// ── PUBLIC: saveStore(newState) ───────────────────────────────────────────────
// Called by UserPortal's update() as: saveStore({ ...getStore(), ...patch })
// We diff against the previous cache to detect what changed, then call the
// right API endpoint(s).  AdminPortal calls api* directly, so for Admin the
// diff never fires.
export function saveStore(newState) {
  const prev = _cache;

  // optimistically update cache so UI reflects changes immediately
  _cache = { ..._cache, ...newState };

  // ── detect notification changes (bookmark / reply / mark-read) ────────────
  if (newState.notifications && Array.isArray(newState.notifications)) {
    newState.notifications.forEach(n => {
      const old = prev.notifications.find(o => o.id === n.id);
      if (!old) return;

      // bookmark toggled
      const oldBm  = old.bookmarkedBy  || [];
      const newBm  = n.bookmarkedBy    || [];
      const addedBm   = newBm.filter(u => !oldBm.includes(u));
      const removedBm = oldBm.filter(u => !newBm.includes(u));
      if (addedBm.length || removedBm.length) {
        // last entry in addedBm or removedBm is the acting user_id (string username)
        // We persist bookmark as user_id integer; for signed-up users we use 0 as fallback
        const userId = 0; // will use username-based lookup on backend
        _req(`/notifications/${n.id}/bookmark-by-username`, {
          method: 'PATCH',
          body: JSON.stringify({ username: addedBm[0] || removedBm[0] }),
        }).catch(() => {});
      }

      // reply added
      const oldReplies = old.replies || [];
      const newReplies = n.replies   || [];
      if (newReplies.length > oldReplies.length) {
        const newest = newReplies[newReplies.length - 1];
        _req(`/notifications/${n.id}/reply`, {
          method: 'POST',
          body: JSON.stringify({ from_user: newest.from, message: newest.message }),
        }).catch(() => {});
      }
    });
  }

  // ── detect new purchase request ───────────────────────────────────────────
  if (newState.purchaseRequests && Array.isArray(newState.purchaseRequests)) {
    const prevIds = new Set((prev.purchaseRequests || []).map(r => r.id));
    newState.purchaseRequests.forEach(r => {
      if (!prevIds.has(r.id)) {
        // new request — submit to API
        _req('/purchases/', {
          method: 'POST',
          body: JSON.stringify({
            user_id:     r.userId,
            user_name:   r.userName,
            material_id: r.materialId,
            quantity:    r.quantity,
          }),
        }).catch(() => {});
      }
    });
  }

  // ── detect new chat message (from user) ───────────────────────────────────
  if (newState.chatMessages && Array.isArray(newState.chatMessages)) {
    const prevIds = new Set((prev.chatMessages || []).map(m => m.id));
    newState.chatMessages.forEach(m => {
      if (!prevIds.has(m.id) && m.from !== 'Admin') {
        // new outgoing user message
        _req('/chat/', {
          method: 'POST',
          body: JSON.stringify({ from_user: m.from, to_user: m.to, message: m.message }),
        }).catch(() => {});
      }
      // mark user-read for admin→user messages
      if (m.readByUser && !prevIds.has(m.id) === false) {
        const old = prev.chatMessages.find(o => o.id === m.id);
        if (old && !old.readByUser && m.readByUser && m.from === 'Admin') {
          _req(`/chat/mark-user-read?to_user=${m.to}`, { method: 'PATCH' }).catch(() => {});
        }
      }
    });
  }
}

// ── PUBLIC: getDefaultStore() ────────────────────────────────────────────────
export function getDefaultStore() { return _emptyStore(); }

// ── Auth ──────────────────────────────────────────────────────────────────────
export async function apiSignIn(username, password) {
  return _req('/auth/signin', { method: 'POST', body: JSON.stringify({ username, password }) });
}
export async function apiSignUp(username, password, name, department) {
  return _req('/auth/signup', { method: 'POST', body: JSON.stringify({ username, password, name, department }) });
}

// ── Notifications ─────────────────────────────────────────────────────────────
export async function apiSendNotification(title, message, type = 'info', userId = 0) {
  return _req('/notifications/send', {
    method: 'POST',
    body: JSON.stringify({ user_id: userId, title, message, type }),
  });
}
export async function apiMarkAllRead(userId) {
  return _req(`/notifications/mark-all-read?user_id=${userId}`, { method: 'PATCH' });
}
export async function apiDeleteNotif(notifId) {
  return _req(`/notifications/${notifId}`, { method: 'DELETE' });
}
export async function apiReplyNotif(notifId, fromUser, message) {
  return _req(`/notifications/${notifId}/reply`, {
    method: 'POST', body: JSON.stringify({ from_user: fromUser, message }),
  });
}
export async function apiToggleBookmark(notifId, userId) {
  return _req(`/notifications/${notifId}/bookmark?user_id=${userId}`, { method: 'PATCH' });
}

// ── Employees ─────────────────────────────────────────────────────────────────
export async function apiAddEmployee(data) {
  return _req('/employees/', { method: 'POST', body: JSON.stringify(data) });
}
export async function apiUpdateEmployee(id, data) {
  return _req(`/employees/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}
export async function apiDeleteEmployee(id) {
  return _req(`/employees/${id}`, { method: 'DELETE' });
}

// ── Materials ─────────────────────────────────────────────────────────────────
export async function apiAddMaterial(data) {
  return _req('/materials/', { method: 'POST', body: JSON.stringify(data) });
}
export async function apiUpdateMaterial(id, data) {
  return _req(`/materials/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}
export async function apiDeleteMaterial(id) {
  return _req(`/materials/${id}`, { method: 'DELETE' });
}

// ── Stores ────────────────────────────────────────────────────────────────────
export async function apiAddStore(data) {
  return _req('/stores/', { method: 'POST', body: JSON.stringify(data) });
}
export async function apiUpdateStore(id, data) {
  return _req(`/stores/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}
export async function apiDeleteStore(id) {
  return _req(`/stores/${id}`, { method: 'DELETE' });
}

// ── Suppliers ─────────────────────────────────────────────────────────────────
export async function apiAddSupplier(data) {
  return _req('/suppliers/', { method: 'POST', body: JSON.stringify(data) });
}
export async function apiUpdateSupplier(id, data) {
  return _req(`/suppliers/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}
export async function apiDeleteSupplier(id) {
  return _req(`/suppliers/${id}`, { method: 'DELETE' });
}

// ── Inventory ─────────────────────────────────────────────────────────────────
export async function apiAddInventory(data) {
  return _req('/inventory/', { method: 'POST', body: JSON.stringify(data) });
}
export async function apiUpdateInventory(id, data) {
  return _req(`/inventory/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}
export async function apiDeleteInventory(id) {
  return _req(`/inventory/${id}`, { method: 'DELETE' });
}

// ── Manufacture ───────────────────────────────────────────────────────────────
export async function apiAddManufacture(data) {
  return _req('/manufacture/', { method: 'POST', body: JSON.stringify(data) });
}
export async function apiUpdateManufacture(id, data) {
  return _req(`/manufacture/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}
export async function apiDeleteManufacture(id) {
  return _req(`/manufacture/${id}`, { method: 'DELETE' });
}

// ── Chat ──────────────────────────────────────────────────────────────────────
export async function apiSendChat(fromUser, toUser, message) {
  return _req('/chat/', {
    method: 'POST', body: JSON.stringify({ from_user: fromUser, to_user: toUser, message }),
  });
}
export async function apiMarkAdminRead(fromUser) {
  return _req(`/chat/mark-admin-read?from_user=${fromUser}`, { method: 'PATCH' });
}
export async function apiMarkUserRead(toUser) {
  return _req(`/chat/mark-user-read?to_user=${toUser}`, { method: 'PATCH' });
}

// ── Purchase Requests ─────────────────────────────────────────────────────────
export async function apiCreatePurchaseRequest(userId, userName, materialId, quantity) {
  return _req('/purchases/', {
    method: 'POST',
    body: JSON.stringify({ user_id: userId, user_name: userName, material_id: materialId, quantity }),
  });
}
export async function apiApprovePurchase(id) {
  return _req(`/purchases/${id}/approve`, { method: 'POST' });
}
export async function apiRejectPurchase(id) {
  return _req(`/purchases/${id}/reject`, { method: 'POST' });
}

// ── Utility ───────────────────────────────────────────────────────────────────
export function formatTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

export function timeAgo(iso) {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  if (diff < 60000)    return 'just now';
  if (diff < 3600000)  return `${Math.floor(diff / 60000)} min ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} hr ago`;
  return `${Math.floor(diff / 86400000)} day(s) ago`;
}
