# SCMS — NIC Portal (Backend Connected)

This project combines the **NIC React frontend** with the **FastAPI + PostgreSQL backend** from the SCMS intent-portal.

## Project Structure

```
scms/
├── frontend/          ← React app (NIC portal, unchanged UI)
│   └── src/
│       ├── api.js     ← NEW: API bridge to FastAPI backend
│       ├── App.js
│       ├── LoginPage.js
│       ├── AdminPortal.js
│       ├── UserPortal.js
│       └── store.js   ← localStorage fallback (unchanged)
├── python_backend/    ← FastAPI + PostgreSQL backend (from scms_intent-portal)
│   ├── main.py        ← FastAPI app entry point (port 8001)
│   ├── database.py    ← PostgreSQL connection (asyncpg + SQLAlchemy)
│   ├── models.py      ← SQLAlchemy models
│   ├── setup.sql      ← DB schema + seed data (auto-runs on startup)
│   ├── requirements.txt
│   ├── .env.example   ← Copy to .env and set your DB URL
│   └── routes/
│       ├── auth.py           ← Login, signup, user list
│       ├── notifications.py  ← Send/fetch/mark-read notifications
│       ├── materials.py      ← CRUD for materials catalog
│       ├── purchase_requests.py ← Submit/approve/reject requests
│       └── indent.py         ← Full indent (purchase requisition) API
└── backend/           ← Original Node.js Express backend (kept, not used)
```

## What's Connected

| NIC Frontend Action | Backend API Endpoint |
|---|---|
| Login / Signup | `POST /api/auth/login`, `POST /api/auth/signup` |
| View Materials | `GET /api/materials` |
| Admin Add/Edit Material | `POST /api/materials`, `PUT /api/materials/{id}` |
| Request Purchase | `POST /api/purchase-requests` |
| Admin Approve/Reject | `POST /api/purchase-requests/{id}/approve|reject` |
| View Notifications | `GET /api/notifications?user_id=X` |
| Admin Send Notification | `POST /api/notifications/send` |
| Indent (requisition) | `POST /api/indent/create`, `GET /api/indent/list` |

## Prerequisites

- **Node.js** v18+ (for React frontend)
- **Python** 3.10+ (for FastAPI backend)
- **PostgreSQL** 14+ running locally (or any PostgreSQL server)

---

## Setup & Run

### Step 1 — Configure the database

1. Make sure PostgreSQL is running.
2. Create a database named `scms`:
   ```sql
   CREATE DATABASE scms;
   ```
3. Copy the env file:
   ```
   cd python_backend
   copy .env.example .env
   ```
4. Edit `.env` and set your credentials:
   ```
   ASYNC_DATABASE_URL=postgresql+asyncpg://postgres:YOUR_PASSWORD@localhost:5432/scms
   ```

### Step 2 — Install Python backend dependencies

```bash
cd scms/python_backend
pip install -r requirements.txt
```

### Step 3 — Start the Python backend

```bash
cd scms               ← IMPORTANT: run from the scms/ folder, not from python_backend/
uvicorn backend.main:app --reload --port 8001
```

> The backend auto-creates all tables and seeds default data on first startup.
> API docs available at: http://localhost:8001/docs

### Step 4 — Install React frontend dependencies

```bash
cd scms/frontend
npm install
```

### Step 5 — Start the React frontend

```bash
cd scms/frontend
npm start
```

> Frontend runs at: http://localhost:3000

---

## Default Login Credentials

| Role | Username | Password |
|---|---|---|
| Admin | `TRP_RDD_2301` | `Scms@2301` |
| User | Sign up via the portal | (your chosen password) |

---

## API Reference

Visit **http://localhost:8001/docs** for the full interactive Swagger UI.
