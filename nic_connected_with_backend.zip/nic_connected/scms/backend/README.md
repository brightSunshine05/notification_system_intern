# SCMS Backend

Backend service for SCMS (Supply Chain Management System).

## Getting Started

1. Navigate to this folder:
   ```bash
   cd nic/scms/backend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the backend:
   ```bash
   npm start
   ```

## API Endpoints

- `GET /api/health` - service health check
- `POST /api/login` - basic login endpoint

## Folder Structure

Place your backend API code here (Node.js / Python / Java / etc.)

## Suggested Stack
- Node.js with Express
- MongoDB / PostgreSQL for database
- JWT for authentication
- Nodemailer for OTP emails
