const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors({ origin: 'http://localhost:3000' }));
app.use(express.json());

// Simple health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'scms-backend' });
});

// Basic login endpoint for future frontend integration
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'username and password are required' });
  }

  if (username === 'TRP_RDD_2301' && password === 'password123') {
    return res.json({ success: true, user: { username, name: 'SCMS User' } });
  }

  return res.status(401).json({ success: false, error: 'Invalid credentials' });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

app.listen(PORT, () => {
  console.log(`SCMS backend listening on http://localhost:${PORT}`);
});
