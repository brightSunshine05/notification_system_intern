/**
 * api.js — NIC SCMS Frontend ↔ FastAPI Backend Bridge
 *
 * All functions talk to the Python backend at http://localhost:8001.
 * The store.js localStorage layer is kept as a local cache / fallback.
 */

const BASE_URL = 'http://localhost:8001';

async function request(method, path, body) {
  try {
    const opts = {
      method,
      headers: { 'Content-Type': 'application/json' },
    };
    if (body !== undefined) opts.body = JSON.stringify(body);
    const res = await fetch(`${BASE_URL}${path}`, opts);
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || `HTTP ${res.status}`);
    return { ok: true, data };
  } catch (err) {
    console.error(`[API] ${method} ${path} failed:`, err.message);
    return { ok: false, error: err.message };
  }
}

// ── Auth ──────────────────────────────────────────────────────────────────────

export async function apiLogin(username, password) {
  return request('POST', '/api/auth/login', { username, password });
}

export async function apiSignup(username, password, name, department) {
  return request('POST', '/api/auth/signup', { username, password, name, department });
}

export async function apiGetUsers() {
  return request('GET', '/api/auth/users');
}

// ── Materials ─────────────────────────────────────────────────────────────────

export async function apiGetMaterials() {
  return request('GET', '/api/materials');
}

export async function apiAddMaterial(mat) {
  return request('POST', '/api/materials', {
    name: mat.name,
    category: mat.category,
    quantity: mat.quantity,
    unit: mat.unit,
    price: mat.price,
    description: mat.description,
    added_by: mat.addedBy || 'Admin',
  });
}

export async function apiUpdateMaterial(id, mat) {
  return request('PUT', `/api/materials/${id}`, {
    name: mat.name,
    category: mat.category,
    quantity: mat.quantity !== undefined ? mat.quantity : undefined,
    unit: mat.unit,
    price: mat.price !== undefined ? mat.price : undefined,
    description: mat.description,
  });
}

export async function apiDeleteMaterial(id) {
  return request('DELETE', `/api/materials/${id}`);
}

// ── Purchase Requests ─────────────────────────────────────────────────────────

export async function apiGetPurchaseRequests(userId, status) {
  let qs = '';
  if (userId !== undefined) qs += `user_id=${userId}`;
  if (status) qs += `${qs ? '&' : ''}status=${status}`;
  return request('GET', `/api/purchase-requests${qs ? '?' + qs : ''}`);
}

export async function apiCreatePurchaseRequest(req) {
  return request('POST', '/api/purchase-requests', {
    user_id: req.userId,
    user_name: req.userName,
    material_id: req.materialId,
    material_name: req.materialName,
    quantity: req.quantity,
  });
}

export async function apiApprovePurchaseRequest(id) {
  return request('POST', `/api/purchase-requests/${id}/approve`, { resolved_by: 'Admin' });
}

export async function apiRejectPurchaseRequest(id) {
  return request('POST', `/api/purchase-requests/${id}/reject`, { resolved_by: 'Admin' });
}

// ── Notifications ─────────────────────────────────────────────────────────────

export async function apiGetNotifications(userId) {
  return request('GET', `/api/notifications?user_id=${userId}`);
}

export async function apiSendNotification(title, message, userId) {
  return request('POST', '/api/notifications/send', {
    title,
    message,
    notif_type: 'info',
    user_id: userId !== undefined ? userId : null,
  });
}

export async function apiMarkNotificationRead(id) {
  return request('POST', `/api/notifications/${id}/read`);
}

export async function apiMarkAllNotificationsRead(userId) {
  return request('POST', `/api/notifications/read-all?user_id=${userId}`);
}

// ── Health check ──────────────────────────────────────────────────────────────
export async function apiHealthCheck() {
  return request('GET', '/api/health');
}
