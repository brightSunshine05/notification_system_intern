// Shared store helpers used across portals
export function getStore() {
  try {
    const raw = localStorage.getItem('scms_store');
    if (raw) return JSON.parse(raw);
  } catch {}
  return getDefaultStore();
}

export function saveStore(data) {
  localStorage.setItem('scms_store', JSON.stringify(data));
}

export function getDefaultStore() {
  return {
    notifications: [
      { id: 1, type: 'info', title: 'System Ready', message: 'SCMS portal is now active and ready for operations.', time: new Date().toISOString(), read: false, from: 'Admin', replies: [], bookmarked: false },
      { id: 2, type: 'alert', title: 'Low Stock Alert', message: 'Item #A-2041 (Bolt M8) is below minimum threshold. Reorder needed.', time: new Date(Date.now() - 3600000).toISOString(), read: false, from: 'Admin', replies: [], bookmarked: false },
    ],
    materials: [
      { id: 1, name: 'Bolt M8', category: 'Hardware', quantity: 50, unit: 'pcs', price: 5.00, description: 'Standard M8 bolts', addedAt: new Date(Date.now() - 86400000).toISOString(), addedBy: 'Admin' },
      { id: 2, name: 'Lubricant LB-220', category: 'Chemical', quantity: 20, unit: 'liters', price: 150.00, description: 'Industrial lubricant batch LB-220', addedAt: new Date(Date.now() - 7200000).toISOString(), addedBy: 'Admin' },
    ],
    employees: [
      { id: 1, empId: 'EMP-0001', name: 'Rajesh Kumar', department: 'Warehouse', role: 'user', email: 'rajesh@scms.in', phone: '9876543210', status: 'Active', joinedAt: new Date(Date.now() - 864000000).toISOString() },
    ],
    stores: [
      { id: 1, storeId: 'STR-001', name: 'Store Alpha', location: 'Building A', manager: 'Rajesh Kumar', capacity: 1000, status: 'Active' },
      { id: 2, storeId: 'STR-002', name: 'Store Beta', location: 'Building B', manager: 'N/A', capacity: 800, status: 'Active' },
    ],
    suppliers: [
      { id: 1, supplierId: 'SUP-001', name: 'RailParts India Ltd', contact: 'Mr. Sharma', phone: '9988776655', email: 'info@railparts.in', materials: 'Bolts, Nuts, Fasteners', status: 'Active' },
    ],
    inventory: [
      { id: 1, itemCode: 'INV-001', name: 'Bolt M8', category: 'Hardware', quantity: 50, minQty: 100, unit: 'pcs', location: 'Store Alpha', supplier: 'RailParts India Ltd' },
      { id: 2, itemCode: 'INV-002', name: 'Lubricant LB-220', category: 'Chemical', quantity: 20, minQty: 30, unit: 'liters', location: 'Store Beta', supplier: 'ChemSupply Co.' },
    ],
    chatMessages: [],
    purchaseRequests: [],
    signedUpUsers: [], // { username, password, name, createdAt } — self-registered portal users
    manufacture: [
      { id: 1, orderId: 'MFG-001', product: 'Rail Bracket Assembly', quantity: 50, status: 'In Progress', startDate: new Date(Date.now() - 172800000).toISOString(), endDate: null, materials: ['Bolt M8 x 200', 'Lubricant LB-220 x 2L'] },
    ],
    seenMaterials: {}, // { userId: [materialId, ...] }
  };
}

export function formatTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export function timeAgo(iso) {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  if (diff < 60000) return 'just now';
  if (diff < 3600000) return `${Math.floor(diff / 60000)} min ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} hr ago`;
  return `${Math.floor(diff / 86400000)} day(s) ago`;
}
