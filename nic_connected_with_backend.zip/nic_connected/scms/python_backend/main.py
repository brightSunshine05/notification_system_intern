import logging
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend.database import init_db
from backend.routes.indent import router as indent_router
from backend.routes.auth import router as auth_router
from backend.routes.notifications import router as notifications_router
from backend.routes.materials import router as materials_router
from backend.routes.purchase_requests import router as purchase_requests_router

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s:%(name)s:%(message)s"
)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="SCMS Backend",
    description="Supply Chain Management System — NIC Portal Backend (FastAPI + PostgreSQL)",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routes ────────────────────────────────────────────────────────────────────
app.include_router(indent_router,           prefix="/api/indent",            tags=["Indent"])
app.include_router(auth_router,             prefix="/api/auth",              tags=["Auth"])
app.include_router(notifications_router,    prefix="/api/notifications",     tags=["Notifications"])
app.include_router(materials_router,        prefix="/api/materials",         tags=["Materials"])
app.include_router(purchase_requests_router,prefix="/api/purchase-requests", tags=["Purchase Requests"])


@app.get("/api/health", tags=["Root"])
async def health():
    return {
        "status": "SCMS NIC Backend running",
        "port": 8001,
        "docs": "http://localhost:8001/docs"
    }


@app.on_event("startup")
async def startup():
    await init_db()
    logger.info("SCMS NIC Backend started on port 8001")


# Serve built React frontend if present (register LAST)
STATIC_DIR = os.getenv("STATIC_DIR", "frontend/build")
if os.path.exists(STATIC_DIR):
    app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
else:
    logger.info(f"Static dir '{STATIC_DIR}' not found — serve frontend separately with 'npm start'")
