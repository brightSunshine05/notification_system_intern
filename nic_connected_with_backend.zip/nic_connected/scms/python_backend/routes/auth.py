"""
Auth routes for NIC SCMS frontend.
- POST /api/auth/login   — validate username/password, return user info
- POST /api/auth/signup  — register a new user
- GET  /api/auth/users   — list all users (admin use)
"""
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text

from backend.database import get_db

router = APIRouter()
logger = logging.getLogger(__name__)


# ── Pydantic schemas (inline to keep it self-contained) ──────────────────────
from pydantic import BaseModel

class LoginRequest(BaseModel):
    username: str
    password: str

class SignupRequest(BaseModel):
    username: str
    password: str
    name: str
    department: Optional[str] = ""

class UserResponse(BaseModel):
    user_id: int
    username: str
    name: str
    department: Optional[str]
    role: str


# ── Routes ───────────────────────────────────────────────────────────────────

@router.post("/login")
async def login(payload: LoginRequest, db: AsyncSession = Depends(get_db)):
    """Authenticate a user. Returns user object on success."""
    result = await db.execute(
        text("SELECT user_id, username, name, department, role, password_hash FROM scms.users WHERE username = :u"),
        {"u": payload.username}
    )
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Simple plain-text comparison (matches what the NIC frontend stored)
    if row.password_hash != payload.password:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    return {
        "success": True,
        "user": {
            "user_id": row.user_id,
            "username": row.username,
            "name": row.name,
            "department": row.department or "",
            "role": row.role,
        }
    }


@router.post("/signup")
async def signup(payload: SignupRequest, db: AsyncSession = Depends(get_db)):
    """Register a new user (role=user by default)."""
    existing = await db.execute(
        text("SELECT user_id FROM scms.users WHERE username = :u"),
        {"u": payload.username}
    )
    if existing.fetchone():
        raise HTTPException(status_code=409, detail="Username already taken")

    result = await db.execute(
        text(
            "INSERT INTO scms.users (username, name, department, role, password_hash) "
            "VALUES (:u, :n, :d, 'user', :p) RETURNING user_id"
        ),
        {"u": payload.username, "n": payload.name, "d": payload.department, "p": payload.password}
    )
    new_id = result.fetchone()[0]
    await db.commit()
    logger.info(f"New user registered: {payload.username} (id={new_id})")
    return {"success": True, "user_id": new_id}


@router.get("/users")
async def list_users(db: AsyncSession = Depends(get_db)):
    """Return all users (for admin to resolve names to IDs)."""
    result = await db.execute(
        text("SELECT user_id, username, name, department, role FROM scms.users ORDER BY user_id")
    )
    rows = result.fetchall()
    return [
        {"user_id": r.user_id, "username": r.username, "name": r.name, "department": r.department, "role": r.role}
        for r in rows
    ]
