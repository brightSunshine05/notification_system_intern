"""
Materials routes for NIC SCMS — maps to scms.materials table.
- GET    /api/materials           — list all materials
- POST   /api/materials           — admin adds a material
- PUT    /api/materials/{id}      — admin edits a material
- DELETE /api/materials/{id}      — admin deletes a material
"""
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from pydantic import BaseModel

from backend.database import get_db

router = APIRouter()
logger = logging.getLogger(__name__)


class MaterialCreate(BaseModel):
    name: str
    category: str
    quantity: int
    unit: str = "pcs"
    price: float = 0.0
    description: Optional[str] = ""
    added_by: Optional[str] = "Admin"


class MaterialUpdate(BaseModel):
    name: Optional[str] = None
    category: Optional[str] = None
    quantity: Optional[int] = None
    unit: Optional[str] = None
    price: Optional[float] = None
    description: Optional[str] = None


@router.get("")
async def list_materials(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text("SELECT material_id, name, category, quantity, unit, price, description, added_by, added_at FROM scms.materials ORDER BY added_at DESC")
    )
    rows = result.fetchall()
    return [
        {
            "id": r.material_id,
            "name": r.name,
            "category": r.category,
            "quantity": r.quantity,
            "unit": r.unit,
            "price": float(r.price or 0),
            "description": r.description or "",
            "addedBy": r.added_by or "Admin",
            "addedAt": r.added_at.isoformat() if r.added_at else None,
        }
        for r in rows
    ]


@router.post("", status_code=201)
async def add_material(payload: MaterialCreate, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        text(
            "INSERT INTO scms.materials (name, category, quantity, unit, price, description, added_by) "
            "VALUES (:name, :cat, :qty, :unit, :price, :desc, :by) RETURNING material_id, added_at"
        ),
        {"name": payload.name, "cat": payload.category, "qty": payload.quantity,
         "unit": payload.unit, "price": payload.price, "desc": payload.description, "by": payload.added_by}
    )
    row = result.fetchone()
    await db.commit()

    # Broadcast notification to all users
    await db.execute(
        text(
            "INSERT INTO public.notifications (user_id, title, message, notif_type) "
            "VALUES (-1, :title, :msg, 'info')"
        ),
        {
            "title": f"New Material: {payload.name}",
            "msg": f"Admin added a new material: {payload.name} ({payload.category}) — {payload.quantity} {payload.unit} @ ₹{payload.price}. Available for purchase.",
        }
    )
    await db.commit()
    logger.info(f"Material added: {payload.name} (id={row.material_id})")
    return {"id": row.material_id, "added_at": row.added_at.isoformat() if row.added_at else None}


@router.put("/{material_id}")
async def update_material(material_id: int, payload: MaterialUpdate, db: AsyncSession = Depends(get_db)):
    sets, params = [], {"mid": material_id}
    if payload.name is not None:
        sets.append("name = :name"); params["name"] = payload.name
    if payload.category is not None:
        sets.append("category = :cat"); params["cat"] = payload.category
    if payload.quantity is not None:
        sets.append("quantity = :qty"); params["qty"] = payload.quantity
    if payload.unit is not None:
        sets.append("unit = :unit"); params["unit"] = payload.unit
    if payload.price is not None:
        sets.append("price = :price"); params["price"] = payload.price
    if payload.description is not None:
        sets.append("description = :desc"); params["desc"] = payload.description
    if not sets:
        raise HTTPException(status_code=400, detail="Nothing to update")
    sets.append("modified_at = NOW()")
    await db.execute(
        text(f"UPDATE scms.materials SET {', '.join(sets)} WHERE material_id = :mid"),
        params
    )
    await db.commit()
    return {"success": True}


@router.delete("/{material_id}")
async def delete_material(material_id: int, db: AsyncSession = Depends(get_db)):
    await db.execute(
        text("DELETE FROM scms.materials WHERE material_id = :mid"),
        {"mid": material_id}
    )
    await db.commit()
    return {"success": True}
