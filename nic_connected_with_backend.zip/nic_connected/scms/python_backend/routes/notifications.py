"""
Notification routes for NIC SCMS frontend.
- GET  /api/notifications?user_id=X   — fetch notifications for a user
- POST /api/notifications/send         — admin sends a broadcast notification
- POST /api/notifications/{id}/read   — mark a notification as read
- POST /api/notifications/read-all    — mark all as read for a user
"""
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from backend.database import get_db

router = APIRouter()
logger = logging.getLogger(__name__)

from pydantic import BaseModel

class SendNotificationRequest(BaseModel):
    user_id: Optional[int] = None    # None = broadcast to all
    title: str
    message: str
    notif_type: str = "info"         # info | alert | success


@router.get("")
async def get_notifications(
    user_id: int = Query(..., description="User ID to fetch notifications for"),
    db: AsyncSession = Depends(get_db)
):
    """Return all notifications for a user (broadcast + personal), newest first."""
    result = await db.execute(
        text(
            "SELECT notification_id, user_id, title, message, notif_type, is_read, created_on "
            "FROM public.notifications "
            "WHERE user_id = :uid OR user_id = -1 "   # -1 = broadcast
            "ORDER BY created_on DESC LIMIT 50"
        ),
        {"uid": user_id}
    )
    rows = result.fetchall()
    return [
        {
            "id": r.notification_id,
            "user_id": r.user_id,
            "title": r.title or "Notification",
            "message": r.message,
            "type": r.notif_type or "info",
            "read": r.is_read,
            "time": r.created_on.isoformat() if r.created_on else None,
            "from": "Admin",
            "replies": [],
            "bookmarked": False,
        }
        for r in rows
    ]


@router.post("/send")
async def send_notification(payload: SendNotificationRequest, db: AsyncSession = Depends(get_db)):
    """Admin sends a notification. user_id=None broadcasts to all (stored as user_id=-1)."""
    uid = payload.user_id if payload.user_id is not None else -1
    await db.execute(
        text(
            "INSERT INTO public.notifications (user_id, title, message, notif_type) "
            "VALUES (:uid, :title, :msg, :ntype)"
        ),
        {"uid": uid, "title": payload.title, "msg": payload.message, "ntype": payload.notif_type}
    )
    await db.commit()
    logger.info(f"Notification sent to user_id={uid}: {payload.title}")
    return {"success": True}


@router.post("/{notification_id}/read")
async def mark_read(notification_id: int, db: AsyncSession = Depends(get_db)):
    await db.execute(
        text("UPDATE public.notifications SET is_read = TRUE WHERE notification_id = :nid"),
        {"nid": notification_id}
    )
    await db.commit()
    return {"success": True}


@router.post("/read-all")
async def mark_all_read(user_id: int = Query(...), db: AsyncSession = Depends(get_db)):
    await db.execute(
        text("UPDATE public.notifications SET is_read = TRUE WHERE user_id = :uid OR user_id = -1"),
        {"uid": user_id}
    )
    await db.commit()
    return {"success": True}
