"""
Purchase request routes for NIC SCMS frontend.
Maps to scms.purchase_requests table.
- GET  /api/purchase-requests             — list (optionally filter by user_id / status)
- POST /api/purchase-requests             — user submits a request
- POST /api/purchase-requests/{id}/approve
- POST /api/purchase-requests/{id}/reject
"""
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from pydantic import BaseModel

from backend.database import get_db

router = APIRouter()
logger = logging.getLogger(__name__)


class PurchaseRequestCreate(BaseModel):
    user_id: int
    user_name: str
    material_id: int
    material_name: str
    quantity: int


class ResolveRequest(BaseModel):
    resolved_by: Optional[str] = "Admin"


@router.get("")
async def list_purchase_requests(
    user_id: Optional[int] = Query(None),
    status: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    where_clauses = []
    params = {}
    if user_id is not None:
        where_clauses.append("user_id = :uid")
        params["uid"] = user_id
    if status:
        where_clauses.append("status = :status")
        params["status"] = status.capitalize()

    where = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""
    result = await db.execute(
        text(f"SELECT * FROM scms.purchase_requests {where} ORDER BY created_at DESC"),
        params
    )
    rows = result.fetchall()
    return [
        {
            "id": r.request_id,
            "userId": r.username,
            "userName": r.user_name,
            "materialId": r.material_id,
            "materialName": r.material_name,
            "quantity": r.quantity,
            "status": r.status,
            "time": r.created_at.isoformat() if r.created_at else None,
            "resolvedAt": r.resolved_at.isoformat() if r.resolved_at else None,
        }
        for r in rows
    ]


@router.post("", status_code=201)
async def create_purchase_request(payload: PurchaseRequestCreate, db: AsyncSession = Depends(get_db)):
    # Look up username from user_id
    user_row = await db.execute(
        text("SELECT username FROM scms.users WHERE user_id = :uid"),
        {"uid": payload.user_id}
    )
    user_row = user_row.fetchone()
    username = user_row.username if user_row else str(payload.user_id)

    result = await db.execute(
        text(
            "INSERT INTO scms.purchase_requests (user_id, username, user_name, material_id, material_name, quantity, status) "
            "VALUES (:uid, :uname, :unamefull, :mid, :mname, :qty, 'Pending') RETURNING request_id, created_at"
        ),
        {
            "uid": payload.user_id, "uname": username, "unamefull": payload.user_name,
            "mid": payload.material_id, "mname": payload.material_name, "qty": payload.quantity,
        }
    )
    row = result.fetchone()
    await db.commit()

    # Notify admin (user_id of admin = 1 by convention, adjust as needed)
    await db.execute(
        text("INSERT INTO public.notifications (user_id, title, message, notif_type) VALUES (1, :title, :msg, 'info')"),
        {
            "title": "New Purchase Request",
            "msg": f"{payload.user_name} requested {payload.quantity} x {payload.material_name}."
        }
    )
    await db.commit()
    logger.info(f"Purchase request created: id={row.request_id}")
    return {"id": row.request_id, "created_at": row.created_at.isoformat() if row.created_at else None}


@router.post("/{request_id}/approve")
async def approve_request(request_id: int, payload: ResolveRequest, db: AsyncSession = Depends(get_db)):
    req = await db.execute(
        text("SELECT * FROM scms.purchase_requests WHERE request_id = :rid"),
        {"rid": request_id}
    )
    req = req.fetchone()
    if not req:
        raise HTTPException(status_code=404, detail="Request not found")
    if req.status != "Pending":
        raise HTTPException(status_code=400, detail=f"Request is already {req.status}")

    # Deduct quantity from materials
    await db.execute(
        text("UPDATE scms.materials SET quantity = GREATEST(0, quantity - :qty), modified_at = NOW() WHERE material_id = :mid"),
        {"qty": req.quantity, "mid": req.material_id}
    )
    # Update status
    await db.execute(
        text("UPDATE scms.purchase_requests SET status='Approved', resolved_at=NOW() WHERE request_id=:rid"),
        {"rid": request_id}
    )
    await db.commit()

    # Notify the requesting user
    await db.execute(
        text("INSERT INTO public.notifications (user_id, title, message, notif_type) VALUES (:uid, :title, :msg, 'success')"),
        {
            "uid": req.user_id,
            "title": "Purchase Request Approved",
            "msg": f"Your request for {req.quantity} {req.material_name} has been approved."
        }
    )
    await db.commit()
    return {"success": True}


@router.post("/{request_id}/reject")
async def reject_request(request_id: int, payload: ResolveRequest, db: AsyncSession = Depends(get_db)):
    req = await db.execute(
        text("SELECT * FROM scms.purchase_requests WHERE request_id = :rid"),
        {"rid": request_id}
    )
    req = req.fetchone()
    if not req:
        raise HTTPException(status_code=404, detail="Request not found")
    if req.status != "Pending":
        raise HTTPException(status_code=400, detail=f"Request is already {req.status}")

    await db.execute(
        text("UPDATE scms.purchase_requests SET status='Rejected', resolved_at=NOW() WHERE request_id=:rid"),
        {"rid": request_id}
    )
    await db.commit()

    # Notify the requesting user
    await db.execute(
        text("INSERT INTO public.notifications (user_id, title, message, notif_type) VALUES (:uid, :title, :msg, 'alert')"),
        {
            "uid": req.user_id,
            "title": "Purchase Request Rejected",
            "msg": f"Your request for {req.quantity} {req.material_name} has been rejected."
        }
    )
    await db.commit()
    return {"success": True}
