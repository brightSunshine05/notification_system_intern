-- ── Schema ──────────────────────────────────────────────────────────────────
CREATE SCHEMA IF NOT EXISTS scms AUTHORIZATION postgres;

-- ── Users ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scms.users
(
    user_id       SERIAL PRIMARY KEY,
    username      VARCHAR(100) UNIQUE NOT NULL,
    name          VARCHAR(200) NOT NULL,
    department    VARCHAR(100),
    role          VARCHAR(20) DEFAULT 'user',   -- 'admin' | 'user'
    password_hash TEXT NOT NULL,                -- stored as plain text to match NIC frontend
    created_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default admin (username: TRP_RDD_2301, password: Scms@2301)
INSERT INTO scms.users (username, name, department, role, password_hash)
VALUES ('TRP_RDD_2301', 'SCMS Admin', 'Administration', 'admin', 'Scms@2301')
ON CONFLICT (username) DO NOTHING;

-- ── Materials ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scms.materials
(
    material_id  SERIAL PRIMARY KEY,
    name         VARCHAR(300) NOT NULL,
    category     VARCHAR(100),
    quantity     INTEGER NOT NULL DEFAULT 0,
    unit         VARCHAR(50) DEFAULT 'pcs',
    price        NUMERIC(12,2) DEFAULT 0,
    description  TEXT,
    added_by     VARCHAR(200) DEFAULT 'Admin',
    added_at     TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    modified_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Seed default materials
INSERT INTO scms.materials (name, category, quantity, unit, price, description, added_by)
VALUES
    ('Bolt M8',        'Hardware', 50,  'pcs',    5.00, 'Standard M8 bolts',         'Admin'),
    ('Lubricant LB-220','Chemical', 20, 'liters', 150.00, 'Industrial lubricant batch LB-220', 'Admin')
ON CONFLICT DO NOTHING;

-- ── Purchase Requests ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scms.purchase_requests
(
    request_id    SERIAL PRIMARY KEY,
    user_id       INTEGER NOT NULL REFERENCES scms.users(user_id),
    username      VARCHAR(100) NOT NULL,
    user_name     VARCHAR(200),
    material_id   INTEGER NOT NULL REFERENCES scms.materials(material_id),
    material_name VARCHAR(300) NOT NULL,
    quantity      INTEGER NOT NULL,
    status        VARCHAR(20) DEFAULT 'Pending',  -- Pending | Approved | Rejected
    created_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    resolved_at   TIMESTAMP WITH TIME ZONE
);

CREATE INDEX IF NOT EXISTS idx_pr_user     ON scms.purchase_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_pr_status   ON scms.purchase_requests(status);

-- ── Indent Master (from SCMS intent-portal) ──────────────────────────────────
CREATE TABLE IF NOT EXISTS scms.indent_master
(
    indent_id        SERIAL PRIMARY KEY,
    indent_no        VARCHAR(50) UNIQUE NOT NULL,
    item_name        VARCHAR(300) NOT NULL,
    quantity         INTEGER NOT NULL,
    uom              VARCHAR(50),
    requested_by     INTEGER NOT NULL,
    requested_by_name VARCHAR(200),
    approver_id      INTEGER,
    store_id         INTEGER,
    dept_code        INTEGER,
    dist_code        INTEGER,
    purpose          TEXT,
    status           VARCHAR(20) DEFAULT 'PENDING',
    remarks          TEXT,
    approved_by      INTEGER,
    approved_by_name VARCHAR(200),
    approved_on      TIMESTAMP WITH TIME ZONE,
    created_on       TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_on       TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION scms.notify_indent()
RETURNS trigger AS $$
DECLARE payload JSON;
BEGIN
    payload = json_build_object(
        'indent_id',  NEW.indent_id,
        'indent_no',  NEW.indent_no,
        'item_name',  NEW.item_name,
        'quantity',   NEW.quantity,
        'status',     NEW.status,
        'requester',  NEW.requested_by,
        'approver',   NEW.approver_id,
        'event',      TG_OP
    );
    PERFORM pg_notify('user_notification', payload::text);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_notify_indent ON scms.indent_master;
CREATE TRIGGER trg_notify_indent
    AFTER INSERT OR UPDATE ON scms.indent_master
    FOR EACH ROW EXECUTE FUNCTION scms.notify_indent();

-- ── Indent Items ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS scms.indent_items
(
    item_id     SERIAL PRIMARY KEY,
    indent_id   INTEGER NOT NULL REFERENCES scms.indent_master(indent_id) ON DELETE CASCADE,
    material_id INTEGER,
    item_name   VARCHAR(300) NOT NULL,
    quantity    INTEGER NOT NULL,
    uom         VARCHAR(50),
    unit_price  NUMERIC(12,2) DEFAULT 0,
    total_price NUMERIC(12,2) GENERATED ALWAYS AS (quantity * unit_price) STORED
);

CREATE INDEX IF NOT EXISTS idx_indent_status    ON scms.indent_master(status);
CREATE INDEX IF NOT EXISTS idx_indent_requester ON scms.indent_master(requested_by);
CREATE INDEX IF NOT EXISTS idx_indent_approver  ON scms.indent_master(approver_id);
CREATE INDEX IF NOT EXISTS idx_indent_created   ON scms.indent_master(created_on DESC);

-- ── Public Notifications (shared table) ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.notifications
(
    notification_id SERIAL PRIMARY KEY,
    user_id         INTEGER NOT NULL,    -- -1 = broadcast to all
    title           VARCHAR(300),
    message         TEXT NOT NULL,
    notif_type      VARCHAR(20) DEFAULT 'info',
    is_read         BOOLEAN NOT NULL DEFAULT FALSE,
    created_on      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Seed a welcome notification
INSERT INTO public.notifications (user_id, title, message, notif_type)
VALUES (-1, 'System Ready', 'SCMS portal is now active and ready for operations.', 'info')
ON CONFLICT DO NOTHING;
