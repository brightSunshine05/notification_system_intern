@REM Maven Wrapper for Windows
@echo off
set MAVEN_PROJECTBASEDIR=%~dp0
if not "%JAVA_HOME%"=="" set JAVACMD="%JAVA_HOME%\bin\java.exe"
if "%JAVACMD%"=="" set JAVACMD=java

%JAVACMD% -classpath "%MAVEN_PROJECTBASEDIR%\.mvn\wrapper\maven-wrapper.jar" ^
  "-Dmaven.multiModuleProjectDirectory=%MAVEN_PROJECTBASEDIR%" ^
  org.apache.maven.wrapper.MavenWrapperMain %*
