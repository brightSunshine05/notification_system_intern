package com.demo.notification.dto;

public class LoginResponse {

    private Long   userId;
    private String username;
    private String message;

    public LoginResponse() {}

    public LoginResponse(Long userId, String username, String message) {
        this.userId   = userId;
        this.username = username;
        this.message  = message;
    }

    public Long   getUserId()   { return userId;   }
    public String getUsername() { return username; }
    public String getMessage()  { return message;  }

    public void setUserId(Long userId)      { this.userId   = userId;   }
    public void setUsername(String username){ this.username = username; }
    public void setMessage(String message)  { this.message  = message;  }
}
