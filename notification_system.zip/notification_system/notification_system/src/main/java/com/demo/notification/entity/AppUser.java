package com.demo.notification.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "user_mapping", schema = "config")
@IdClass(AppUserId.class)
public class AppUser {

    @Id
    @Column(name = "emp_code")
    private Integer empCode;

    @Id
    @Column(name = "orgcode")
    private Integer orgCode;

    @Id
    @Column(name = "userid")
    private Integer userId;

    @Column(name = "username", nullable = false)
    private String username;

    @Column(name = "pwd", nullable = false)
    private String pwd;

    @Column(name = "emp_name", nullable = false)
    private String empName;

    @Column(name = "block_emp")
    private Integer blockEmp = 0;

    @Column(name = "is_expired")
    private Integer isExpired = 0;

    // ── Getters ──
    public Integer getEmpCode()  { return empCode;  }
    public Integer getOrgCode()  { return orgCode;  }
    public Integer getUserId()   { return userId;   }
    public String  getUsername() { return username; }
    public String  getPwd()      { return pwd;      }
    public String  getEmpName()  { return empName;  }
    public Integer getBlockEmp() { return blockEmp; }
    public Integer getIsExpired(){ return isExpired; }

    // ── Setters ──
    public void setEmpCode(Integer empCode)   { this.empCode  = empCode;  }
    public void setOrgCode(Integer orgCode)   { this.orgCode  = orgCode;  }
    public void setUserId(Integer userId)     { this.userId   = userId;   }
    public void setUsername(String username)  { this.username = username; }
    public void setPwd(String pwd)            { this.pwd      = pwd;      }
    public void setEmpName(String empName)    { this.empName  = empName;  }
    public void setBlockEmp(Integer blockEmp) { this.blockEmp = blockEmp; }
    public void setIsExpired(Integer isExpired){ this.isExpired = isExpired; }
}
