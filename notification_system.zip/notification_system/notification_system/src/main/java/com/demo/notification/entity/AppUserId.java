package com.demo.notification.entity;

import java.io.Serializable;
import java.util.Objects;

public class AppUserId implements Serializable {

    private Integer empCode;
    private Integer orgCode;
    private Integer userId;

    public AppUserId() {}

    public AppUserId(Integer empCode, Integer orgCode, Integer userId) {
        this.empCode = empCode;
        this.orgCode = orgCode;
        this.userId  = userId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AppUserId)) return false;
        AppUserId that = (AppUserId) o;
        return Objects.equals(empCode, that.empCode)
            && Objects.equals(orgCode, that.orgCode)
            && Objects.equals(userId,  that.userId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(empCode, orgCode, userId);
    }
}
