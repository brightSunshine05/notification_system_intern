package com.demo.notification.entity;

import jakarta.persistence.*;

@Entity
public class Notification {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long senderId;
    private Long receiverId;
    private String message;

    public Notification() {}

    public Notification(Long senderId, Long receiverId, String message) {
        this.senderId   = senderId;
        this.receiverId = receiverId;
        this.message    = message;
    }

    public Long   getId()         { return id;         }
    public Long   getSenderId()   { return senderId;   }
    public Long   getReceiverId() { return receiverId; }
    public String getMessage()    { return message;    }

    public void setSenderId(Long senderId)     { this.senderId   = senderId;   }
    public void setReceiverId(Long receiverId) { this.receiverId = receiverId; }
    public void setMessage(String message)     { this.message    = message;    }
}
