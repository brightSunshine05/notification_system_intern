package com.demo.notification.repository;

import com.demo.notification.entity.AppUser;
import com.demo.notification.entity.AppUserId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AppUserRepository extends JpaRepository<AppUser, AppUserId> {

    Optional<AppUser> findFirstByUsername(String username);
}
