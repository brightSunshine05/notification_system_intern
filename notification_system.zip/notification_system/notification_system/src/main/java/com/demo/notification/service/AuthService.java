package com.demo.notification.service;

import com.demo.notification.dto.LoginRequest;
import com.demo.notification.dto.LoginResponse;
import com.demo.notification.entity.AppUser;
import com.demo.notification.repository.AppUserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private AppUserRepository userRepository;

    /**
     * Validates username + password against config.user_mapping.
     *
     * NOTE: The existing schema stores passwords as plain text in the `pwd`
     * column.  If your deployment hashes them (e.g. BCrypt), replace the
     * plain-text comparison below with your password encoder's matches()
     * method.
     */
    public LoginResponse login(LoginRequest request) {

        Optional<AppUser> optUser =
                userRepository.findFirstByUsername(request.getUsername());

        if (optUser.isEmpty()) {
            return null;   // username not found
        }

        AppUser user = optUser.get();

        // Block check
        if (user.getBlockEmp() != null && user.getBlockEmp() == 1) {
            return null;
        }

        // Expired check
        if (user.getIsExpired() != null && user.getIsExpired() == 1) {
            return null;
        }

        // Plain-text password comparison (change to BCrypt if needed)
        if (!request.getPassword().equals(user.getPwd())) {
            return null;   // wrong password
        }

        return new LoginResponse(
                user.getUserId().longValue(),
                user.getUsername(),
                "Login successful"
        );
    }
}
