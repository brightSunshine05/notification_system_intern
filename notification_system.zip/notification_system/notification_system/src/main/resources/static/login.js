/* ── CAPTCHA ───────────────────────────────────────────── */
let currentCaptcha = '';

function generateCaptcha() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
        code += chars[Math.floor(Math.random() * chars.length)];
    }
    return code;
}

function drawCaptcha(code) {
    const canvas = document.getElementById('captcha-canvas');
    const ctx    = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    // Background
    ctx.fillStyle = '#f0f4ff';
    ctx.fillRect(0, 0, w, h);

    // Noise lines
    for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.moveTo(Math.random() * w, Math.random() * h);
        ctx.lineTo(Math.random() * w, Math.random() * h);
        ctx.strokeStyle = `hsl(${Math.random()*360},60%,70%)`;
        ctx.lineWidth = 1;
        ctx.stroke();
    }

    // Noise dots
    for (let i = 0; i < 30; i++) {
        ctx.beginPath();
        ctx.arc(Math.random() * w, Math.random() * h, 1, 0, Math.PI * 2);
        ctx.fillStyle = `hsl(${Math.random()*360},60%,60%)`;
        ctx.fill();
    }

    // Draw each character with slight rotation and varied colour/size
    const colors = ['#1d4ed8', '#7c3aed', '#dc2626', '#065f46', '#92400e'];
    const charW  = w / code.length;
    for (let i = 0; i < code.length; i++) {
        ctx.save();
        ctx.font = `bold ${20 + Math.floor(Math.random()*6)}px Arial`;
        ctx.fillStyle = colors[i % colors.length];
        ctx.translate(charW * i + charW / 2, h / 2 + 6);
        ctx.rotate((Math.random() - 0.5) * 0.4);
        ctx.textAlign = 'center';
        ctx.fillText(code[i], 0, 0);
        ctx.restore();
    }
}

function refreshCaptcha() {
    currentCaptcha = generateCaptcha();
    drawCaptcha(currentCaptcha);
    document.getElementById('captcha-input').value = '';
}

/* ── Mode switching ──────────────────────────────────────── */
function switchMode(mode) {
    const pwFields  = document.getElementById('password-fields');
    const otpFields = document.getElementById('otp-fields');
    const signinBtn = document.getElementById('signin-btn');

    clearError();

    if (mode === 'password') {
        pwFields.classList.remove('hidden');
        otpFields.classList.add('hidden');
        document.getElementById('btn-text').textContent = 'Sign in';
    } else {
        pwFields.classList.add('hidden');
        otpFields.classList.remove('hidden');
        document.getElementById('btn-text').textContent = 'Verify OTP';
    }
}

/* ── OTP send ────────────────────────────────────────────── */
let otpSent = false;

function sendOtp() {
    const id = document.getElementById('otp-username').value.trim();
    if (!id) { showError('Please enter your Employee ID or mobile number.'); return; }

    // Simulate OTP send (wire to your real OTP endpoint if needed)
    document.getElementById('otp-code').classList.remove('hidden');
    document.getElementById('otp-send-wrap').innerHTML =
        `<p style="font-size:12px;color:#16a34a;margin-bottom:10px;">✔ OTP sent to registered mobile number.</p>`;
    otpSent = true;
}

function handleEnterOtp(e) { if (e.key === 'Enter') doLogin(); }

/* ── Helpers ─────────────────────────────────────────────── */
function showError(msg) {
    const el = document.getElementById('error-msg');
    el.textContent = msg;
    el.classList.remove('hidden');
}
function clearError() {
    document.getElementById('error-msg').classList.add('hidden');
}
function setLoading(on) {
    const btn  = document.getElementById('signin-btn');
    const text = document.getElementById('btn-text');
    const spin = document.getElementById('btn-spin');
    btn.disabled = on;
    spin.classList.toggle('hidden', !on);
    if (!on) {
        const mode = document.querySelector('input[name="loginType"]:checked').value;
        text.textContent = mode === 'otp' ? 'Verify OTP' : 'Sign in';
    } else {
        text.textContent = 'Please wait…';
    }
}

/* ── Main login handler ──────────────────────────────────── */
async function doLogin() {
    clearError();
    const mode = document.querySelector('input[name="loginType"]:checked').value;

    if (mode === 'password') {
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const captcha  = document.getElementById('captcha-input').value.trim().toUpperCase();

        if (!username) { showError('Please enter your username.'); return; }
        if (!password) { showError('Please enter your password.');  return; }
        if (!captcha)  { showError('Please enter the captcha text.'); return; }
        if (captcha !== currentCaptcha) {
            showError('Captcha does not match. Please try again.');
            refreshCaptcha();
            return;
        }

        setLoading(true);
        try {
            const res = await fetch('/api/auth/login', {
                method:  'POST',
                headers: { 'Content-Type': 'application/json' },
                body:    JSON.stringify({ username, password })
            });

            if (res.ok) {
                const data = await res.json();
                sessionStorage.setItem('userId',   data.userId);
                sessionStorage.setItem('username', data.username);
                window.location.href = '/index.html';
            } else {
                const body = await res.json().catch(() => ({}));
                showError(body.message || 'Invalid username or password.');
                refreshCaptcha();
            }
        } catch {
            showError('Cannot reach server. Please try again.');
        } finally {
            setLoading(false);
        }

    } else {
        // OTP mode
        if (!otpSent) { sendOtp(); return; }
        const otp = document.getElementById('otp-code').value.trim();
        if (!otp) { showError('Please enter the OTP.'); return; }
        // Placeholder: hook to real OTP verify endpoint
        showError('OTP verification endpoint not configured yet.');
    }
}

function handleEnter(e) { if (e.key === 'Enter') doLogin(); }

/* ── Init ───────────────────────────────────────────────── */
window.addEventListener('DOMContentLoaded', () => {
    refreshCaptcha();
    document.getElementById('username').focus();
});
