let stompClient   = null;
let currentUserId = null;

// ── On load: pre-fill user ID from login session ──
window.addEventListener('DOMContentLoaded', () => {
    const storedId   = sessionStorage.getItem('userId');
    const storedName = sessionStorage.getItem('username');

    if (!storedId) {
        // Not logged in – redirect to login
        window.location.href = '/login.html';
        return;
    }

    const pill = document.getElementById('user-pill');
    if (storedId && storedId !== 'guest') {
        document.getElementById('currentUser').value = storedId;
        pill.innerHTML = `
            <span>👤 ${storedName || 'User ' + storedId}</span>
            <button class="logout-btn" onclick="logout()">Log out</button>
        `;
        connectUser();   // auto-connect when coming from login
    } else {
        pill.innerHTML = `
            <span>👤 Guest</span>
            <button class="logout-btn" onclick="logout()">Log out</button>
        `;
    }
});

function logout() {
    if (stompClient) stompClient.disconnect();
    sessionStorage.clear();
    window.location.href = '/login.html';
}

function connectUser() {
    currentUserId = document.getElementById('currentUser').value;

    if (!currentUserId) {
        alert('Please enter your user ID first.');
        return;
    }

    const socket  = new SockJS('/ws');
    stompClient   = Stomp.over(socket);
    stompClient.debug = null;   // silence console noise

    stompClient.connect({}, function () {
        console.log('WebSocket connected');
        document.getElementById('status').innerText = '🟢 WebSocket Connected';

        stompClient.subscribe(
            '/topic/notifications/' + currentUserId,
            function (notification) {
                const data = JSON.parse(notification.body);
                showNotification(data.message, data.senderId);
            }
        );
    }, function (err) {
        document.getElementById('status').innerText = '🔴 Connection failed. Retry?';
        console.error('STOMP error', err);
    });
}

function sendNotification() {
    if (!stompClient || !stompClient.connected) {
        alert('Not connected. Please connect first.');
        return;
    }

    const receiverId = document.getElementById('targetUserId').value;
    const message    = document.getElementById('message').value.trim();

    if (!receiverId) { alert('Enter a receiver user ID.'); return; }
    if (!message)    { alert('Enter a message.');          return; }

    const notification = {
        senderId:   currentUserId,
        receiverId: receiverId,
        message:    message
    };

    stompClient.send('/app/sendMessage', {}, JSON.stringify(notification));

    // Clear message field after send
    document.getElementById('message').value = '';
}

function showNotification(message, senderId) {
    const container = document.getElementById('notifications');
    const div       = document.createElement('div');
    div.className   = 'notification';
    div.innerHTML   = `
        <h3>NEW MESSAGE ${senderId ? '<span class="sender">from User ' + senderId + '</span>' : ''}</h3>
        <p>${escapeHtml(message)}</p>
        <span class="notif-time">${new Date().toLocaleTimeString()}</span>
    `;
    container.prepend(div);
}

function escapeHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
